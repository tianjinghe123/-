<template>
	<web-view class="page_web" id="web" :src="url"></web-view>
</template>

<script>
	export default {
		url: "https://uniapp.dcloud.io/static/web-view.html"
	}
</script>

<style>
</style>
