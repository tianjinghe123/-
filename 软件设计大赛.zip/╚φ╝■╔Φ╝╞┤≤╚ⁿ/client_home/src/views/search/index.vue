<template>
  <div class="page_search">
	<div class="warp">
	  <div class="container">
		<div class="row">
		  <div class="col-12">
			<div class="card_result_search">
			  <div class="title">搜索结果</div>

				<!-- 文章搜索结果 -->
			  <list_result_search
				:list="result_article"
				title="招聘资讯"
				source_table="article"
			  ></list_result_search>


						  <list_result_search
				v-if="$check_action('/registered_user/list', 'get')"
				:list="result_registered_user_user_no"
				title="注册用户用户编号"
				source_table="registered_user"
			  ></list_result_search>
														  <list_result_search
				v-if="$check_action('/registered_user/list', 'get')"
				:list="result_registered_user_education"
				title="注册用户学历"
				source_table="registered_user"
			  ></list_result_search>
								  <list_result_search
				v-if="$check_action('/registered_user/list', 'get')"
				:list="result_registered_user_university_one_is_graduated_from"
				title="注册用户毕业院校"
				source_table="registered_user"
			  ></list_result_search>
									  <list_result_search
				v-if="$check_action('/recruitment_enterprise/list', 'get')"
				:list="result_recruitment_enterprise_enterprise_no"
				title="招聘企业企业编号"
				source_table="recruitment_enterprise"
			  ></list_result_search>
								  <list_result_search
				v-if="$check_action('/recruitment_enterprise/list', 'get')"
				:list="result_recruitment_enterprise_enterprise_name"
				title="招聘企业企业名称"
				source_table="recruitment_enterprise"
			  ></list_result_search>
												  <list_result_search
				v-if="$check_action('/position_classification/list', 'get')"
				:list="result_position_classification_position_category"
				title="职位分类职位类别"
				source_table="position_classification"
			  ></list_result_search>
									  <list_result_search
				v-if="$check_action('/regional_management/list', 'get')"
				:list="result_regional_management_region"
				title="地区管理地区"
				source_table="regional_management"
			  ></list_result_search>
												  <list_result_search
				v-if="$check_action('/recruitment_position/list', 'get')"
				:list="result_recruitment_position_enterprise_name"
				title="招聘职位企业名称"
				source_table="recruitment_position"
			  ></list_result_search>
								  <list_result_search
				v-if="$check_action('/recruitment_position/list', 'get')"
				:list="result_recruitment_position_position_name"
				title="招聘职位职位名称"
				source_table="recruitment_position"
			  ></list_result_search>
								  <list_result_search
				v-if="$check_action('/recruitment_position/list', 'get')"
				:list="result_recruitment_position_position_category"
				title="招聘职位职位类别"
				source_table="recruitment_position"
			  ></list_result_search>
								  <list_result_search
				v-if="$check_action('/recruitment_position/list', 'get')"
				:list="result_recruitment_position_region"
				title="招聘职位地区"
				source_table="recruitment_position"
			  ></list_result_search>
																																	  <list_result_search
				v-if="$check_action('/resume_delivery/list', 'get')"
				:list="result_resume_delivery_enterprise_name"
				title="简历投递企业名称"
				source_table="resume_delivery"
			  ></list_result_search>
								  <list_result_search
				v-if="$check_action('/resume_delivery/list', 'get')"
				:list="result_resume_delivery_position_name"
				title="简历投递职位名称"
				source_table="resume_delivery"
			  ></list_result_search>
																																				  <list_result_search
				v-if="$check_action('/invitation_for_interview/list', 'get')"
				:list="result_invitation_for_interview_enterprise_name"
				title="面试邀请企业名称"
				source_table="invitation_for_interview"
			  ></list_result_search>
											  <list_result_search
				v-if="$check_action('/invitation_for_interview/list', 'get')"
				:list="result_invitation_for_interview_full_name"
				title="面试邀请姓名"
				source_table="invitation_for_interview"
			  ></list_result_search>
								  <list_result_search
				v-if="$check_action('/invitation_for_interview/list', 'get')"
				:list="result_invitation_for_interview_position_name"
				title="面试邀请职位名称"
				source_table="invitation_for_interview"
			  ></list_result_search>
																		  <list_result_search
				v-if="$check_action('/position_salary/list', 'get')"
				:list="result_position_salary_particular_year"
				title="职位薪资年份"
				source_table="position_salary"
			  ></list_result_search>
								  <list_result_search
				v-if="$check_action('/position_salary/list', 'get')"
				:list="result_position_salary_position_category"
				title="职位薪资职位类别"
				source_table="position_salary"
			  ></list_result_search>
												</div>
		  </div>
		</div>
	  </div>
	</div>
  </div>
</template>

<script>
import mixin from "../../mixins/page.js";
import list_result_search from "../../components/diy/list_result_search.vue";

export default {
  mixins: [mixin],
  data() {
	return {
	  "query": {
		word: "",
	  },
	  "result_article": [],
						"result_registered_user_user_no":[],
														"result_registered_user_education":[],
								"result_registered_user_university_one_is_graduated_from":[],
									"result_recruitment_enterprise_enterprise_no":[],
								"result_recruitment_enterprise_enterprise_name":[],
												"result_position_classification_position_category":[],
									"result_regional_management_region":[],
												"result_recruitment_position_enterprise_name":[],
								"result_recruitment_position_position_name":[],
								"result_recruitment_position_position_category":[],
								"result_recruitment_position_region":[],
																																	"result_resume_delivery_enterprise_name":[],
								"result_resume_delivery_position_name":[],
																																				"result_invitation_for_interview_enterprise_name":[],
											"result_invitation_for_interview_full_name":[],
								"result_invitation_for_interview_position_name":[],
																		"result_position_salary_particular_year":[],
								"result_position_salary_position_category":[],
										};
  },
  methods: {
	/**
	 * 获取文章
	 */
	get_article() {
	  this.$get("~/api/article/get_list?like=0", { page: 1, size: 10, title: this.query.word }, (json) => {
		if (json.result) {
		  this.result_article = json.result.list;
		}
	  });
	},

				/**
	 * 获取user_no
	 */
	get_registered_user_user_no(){
		let url = "~/api/registered_user/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "user_no": this.query.word }, (json) => {
		  if (json.result) {
			var result_registered_user_user_no = json.result.list;
			result_registered_user_user_no.map(o => o.title = o['user_no'])
	  			this.result_registered_user_user_no = result_registered_user_user_no
		 	}
		});
	},
												/**
	 * 获取education
	 */
	get_registered_user_education(){
		let url = "~/api/registered_user/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "education": this.query.word }, (json) => {
		  if (json.result) {
			var result_registered_user_education = json.result.list;
			result_registered_user_education.map(o => o.title = o['education'])
	  			this.result_registered_user_education = result_registered_user_education
		 	}
		});
	},
						/**
	 * 获取university_one_is_graduated_from
	 */
	get_registered_user_university_one_is_graduated_from(){
		let url = "~/api/registered_user/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "university_one_is_graduated_from": this.query.word }, (json) => {
		  if (json.result) {
			var result_registered_user_university_one_is_graduated_from = json.result.list;
			result_registered_user_university_one_is_graduated_from.map(o => o.title = o['university_one_is_graduated_from'])
	  			this.result_registered_user_university_one_is_graduated_from = result_registered_user_university_one_is_graduated_from
		 	}
		});
	},
							/**
	 * 获取enterprise_no
	 */
	get_recruitment_enterprise_enterprise_no(){
		let url = "~/api/recruitment_enterprise/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "enterprise_no": this.query.word }, (json) => {
		  if (json.result) {
			var result_recruitment_enterprise_enterprise_no = json.result.list;
			result_recruitment_enterprise_enterprise_no.map(o => o.title = o['enterprise_no'])
	  			this.result_recruitment_enterprise_enterprise_no = result_recruitment_enterprise_enterprise_no
		 	}
		});
	},
						/**
	 * 获取enterprise_name
	 */
	get_recruitment_enterprise_enterprise_name(){
		let url = "~/api/recruitment_enterprise/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "enterprise_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_recruitment_enterprise_enterprise_name = json.result.list;
			result_recruitment_enterprise_enterprise_name.map(o => o.title = o['enterprise_name'])
	  			this.result_recruitment_enterprise_enterprise_name = result_recruitment_enterprise_enterprise_name
		 	}
		});
	},
										/**
	 * 获取position_category
	 */
	get_position_classification_position_category(){
		let url = "~/api/position_classification/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "position_category": this.query.word }, (json) => {
		  if (json.result) {
			var result_position_classification_position_category = json.result.list;
			result_position_classification_position_category.map(o => o.title = o['position_category'])
	  			this.result_position_classification_position_category = result_position_classification_position_category
		 	}
		});
	},
							/**
	 * 获取region
	 */
	get_regional_management_region(){
		let url = "~/api/regional_management/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "region": this.query.word }, (json) => {
		  if (json.result) {
			var result_regional_management_region = json.result.list;
			result_regional_management_region.map(o => o.title = o['region'])
	  			this.result_regional_management_region = result_regional_management_region
		 	}
		});
	},
										/**
	 * 获取enterprise_name
	 */
	get_recruitment_position_enterprise_name(){
		let url = "~/api/recruitment_position/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "enterprise_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_recruitment_position_enterprise_name = json.result.list;
			result_recruitment_position_enterprise_name.map(o => o.title = o['enterprise_name'])
	  			this.result_recruitment_position_enterprise_name = result_recruitment_position_enterprise_name
		 	}
		});
	},
						/**
	 * 获取position_name
	 */
	get_recruitment_position_position_name(){
		let url = "~/api/recruitment_position/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "position_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_recruitment_position_position_name = json.result.list;
			result_recruitment_position_position_name.map(o => o.title = o['position_name'])
	  			this.result_recruitment_position_position_name = result_recruitment_position_position_name
		 	}
		});
	},
						/**
	 * 获取position_category
	 */
	get_recruitment_position_position_category(){
		let url = "~/api/recruitment_position/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "position_category": this.query.word }, (json) => {
		  if (json.result) {
			var result_recruitment_position_position_category = json.result.list;
			result_recruitment_position_position_category.map(o => o.title = o['position_category'])
	  			this.result_recruitment_position_position_category = result_recruitment_position_position_category
		 	}
		});
	},
						/**
	 * 获取region
	 */
	get_recruitment_position_region(){
		let url = "~/api/recruitment_position/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "region": this.query.word }, (json) => {
		  if (json.result) {
			var result_recruitment_position_region = json.result.list;
			result_recruitment_position_region.map(o => o.title = o['region'])
	  			this.result_recruitment_position_region = result_recruitment_position_region
		 	}
		});
	},
																															/**
	 * 获取enterprise_name
	 */
	get_resume_delivery_enterprise_name(){
		let url = "~/api/resume_delivery/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "enterprise_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_resume_delivery_enterprise_name = json.result.list;
			result_resume_delivery_enterprise_name.map(o => o.title = o['enterprise_name'])
	  			this.result_resume_delivery_enterprise_name = result_resume_delivery_enterprise_name
		 	}
		});
	},
						/**
	 * 获取position_name
	 */
	get_resume_delivery_position_name(){
		let url = "~/api/resume_delivery/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "position_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_resume_delivery_position_name = json.result.list;
			result_resume_delivery_position_name.map(o => o.title = o['position_name'])
	  			this.result_resume_delivery_position_name = result_resume_delivery_position_name
		 	}
		});
	},
																																		/**
	 * 获取enterprise_name
	 */
	get_invitation_for_interview_enterprise_name(){
		let url = "~/api/invitation_for_interview/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "enterprise_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_invitation_for_interview_enterprise_name = json.result.list;
			result_invitation_for_interview_enterprise_name.map(o => o.title = o['enterprise_name'])
	  			this.result_invitation_for_interview_enterprise_name = result_invitation_for_interview_enterprise_name
		 	}
		});
	},
									/**
	 * 获取full_name
	 */
	get_invitation_for_interview_full_name(){
		let url = "~/api/invitation_for_interview/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "full_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_invitation_for_interview_full_name = json.result.list;
			result_invitation_for_interview_full_name.map(o => o.title = o['full_name'])
	  			this.result_invitation_for_interview_full_name = result_invitation_for_interview_full_name
		 	}
		});
	},
						/**
	 * 获取position_name
	 */
	get_invitation_for_interview_position_name(){
		let url = "~/api/invitation_for_interview/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "position_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_invitation_for_interview_position_name = json.result.list;
			result_invitation_for_interview_position_name.map(o => o.title = o['position_name'])
	  			this.result_invitation_for_interview_position_name = result_invitation_for_interview_position_name
		 	}
		});
	},
																/**
	 * 获取particular_year
	 */
	get_position_salary_particular_year(){
		let url = "~/api/position_salary/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "particular_year": this.query.word }, (json) => {
		  if (json.result) {
			var result_position_salary_particular_year = json.result.list;
			result_position_salary_particular_year.map(o => o.title = o['particular_year'])
	  			this.result_position_salary_particular_year = result_position_salary_particular_year
		 	}
		});
	},
						/**
	 * 获取position_category
	 */
	get_position_salary_position_category(){
		let url = "~/api/position_salary/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "position_category": this.query.word }, (json) => {
		  if (json.result) {
			var result_position_salary_position_category = json.result.list;
			result_position_salary_position_category.map(o => o.title = o['position_category'])
	  			this.result_position_salary_position_category = result_position_salary_position_category
		 	}
		});
	},
									
  },
  components: { list_result_search },
	created(){
    this.query.word = this.$route.query.word || "";
  },
  mounted() {
	this.get_article();
					this.get_registered_user_user_no();
													this.get_registered_user_education();
							this.get_registered_user_university_one_is_graduated_from();
								this.get_recruitment_enterprise_enterprise_no();
							this.get_recruitment_enterprise_enterprise_name();
											this.get_position_classification_position_category();
								this.get_regional_management_region();
											this.get_recruitment_position_enterprise_name();
							this.get_recruitment_position_position_name();
							this.get_recruitment_position_position_category();
							this.get_recruitment_position_region();
																																this.get_resume_delivery_enterprise_name();
							this.get_resume_delivery_position_name();
																																			this.get_invitation_for_interview_enterprise_name();
										this.get_invitation_for_interview_full_name();
							this.get_invitation_for_interview_position_name();
																	this.get_position_salary_particular_year();
							this.get_position_salary_position_category();
									  },
  watch: {
	$route() {
	  $.push(this.query, this.$route.query);
	  this.get_article();
				  this.get_registered_user_user_no();
												  this.get_registered_user_education();
						  this.get_registered_user_university_one_is_graduated_from();
							  this.get_recruitment_enterprise_enterprise_no();
						  this.get_recruitment_enterprise_enterprise_name();
										  this.get_position_classification_position_category();
							  this.get_regional_management_region();
										  this.get_recruitment_position_enterprise_name();
						  this.get_recruitment_position_position_name();
						  this.get_recruitment_position_position_category();
						  this.get_recruitment_position_region();
																															  this.get_resume_delivery_enterprise_name();
						  this.get_resume_delivery_position_name();
																																		  this.get_invitation_for_interview_enterprise_name();
									  this.get_invitation_for_interview_full_name();
						  this.get_invitation_for_interview_position_name();
																  this.get_position_salary_particular_year();
						  this.get_position_salary_position_category();
										},
  },
};
</script>

<style scoped>
.card_search {
  text-align: center;
}
.card_result_search>.title {
  text-align: center;
  padding: 10px 0;
}
</style>
