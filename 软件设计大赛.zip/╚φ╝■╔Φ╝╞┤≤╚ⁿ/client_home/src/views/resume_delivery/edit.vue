<template>
	<div class="diy_edit page_resume_delivery" id="resume_delivery_edit">
		<div class='warp'>
			<div class='container'>
				<div class='row diy_edit_content_box'>
						<div v-if="$check_field('set','enterprise_no') || $check_field('add','enterprise_no') || $check_field('get','enterprise_no')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								企业编号:
							</span>
						</div>
						<div class="diy_field diy_down">
							<select id="form_enterprise_no" :disabled="disabledObj['enterprise_no_isDisabled']" v-model="form['enterprise_no']" v-if="(form['enterprise_no'] && $check_field('set','enterprise_no')) || (!form['enterprise_no'] && $check_field('add','enterprise_no'))" >
								<option v-for="o in list_user_enterprise_no" :value="o['user_id']">
									{{o['nickname'] + '-' + o['username']}}
								</option>
							</select>
							<span v-else-if="$check_field('get','enterprise_no')">{{ form['enterprise_no'] }}</span>
						</div>
					</div>
							<div v-if="$check_field('set','enterprise_name') || $check_field('add','enterprise_name') || $check_field('get','enterprise_name')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								企业名称:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_enterprise_name" v-model="form['enterprise_name']" placeholder="请输入企业名称" v-if="(form['enterprise_name'] && $check_field('set','enterprise_name')) || (!form['enterprise_name'] && $check_field('add','enterprise_name'))"  :disabled="disabledObj['enterprise_name_isDisabled']"/>
							<span v-else-if="$check_field('get','enterprise_name')">{{ form['${obj.name}'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','position_name') || $check_field('add','position_name') || $check_field('get','position_name')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								职位名称:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_position_name" v-model="form['position_name']" placeholder="请输入职位名称" v-if="(form['position_name'] && $check_field('set','position_name')) || (!form['position_name'] && $check_field('add','position_name'))"  :disabled="disabledObj['position_name_isDisabled']"/>
							<span v-else-if="$check_field('get','position_name')">{{ form['${obj.name}'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','position_category') || $check_field('add','position_category') || $check_field('get','position_category')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								职位类别:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_position_category" v-model="form['position_category']" placeholder="请输入职位类别" v-if="(form['position_category'] && $check_field('set','position_category')) || (!form['position_category'] && $check_field('add','position_category'))"  :disabled="disabledObj['position_category_isDisabled']"/>
							<span v-else-if="$check_field('get','position_category')">{{ form['${obj.name}'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','user_no') || $check_field('add','user_no') || $check_field('get','user_no')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								用户编号:
							</span>
						</div>
						<div class="diy_field diy_down">
							<select id="form_user_no" :disabled="disabledObj['user_no_isDisabled']" v-model="form['user_no']" v-if="(form['user_no'] && $check_field('set','user_no')) || (!form['user_no'] && $check_field('add','user_no'))" >
								<option v-for="o in list_user_user_no" :value="o['user_id']">
									{{o['nickname'] + '-' + o['username']}}
								</option>
							</select>
							<span v-else-if="$check_field('get','user_no')">{{ form['user_no'] }}</span>
						</div>
					</div>
							<div v-if="$check_field('set','full_name') || $check_field('add','full_name') || $check_field('get','full_name')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								姓名:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_full_name" v-model="form['full_name']" placeholder="请输入姓名" v-if="(form['full_name'] && $check_field('set','full_name')) || (!form['full_name'] && $check_field('add','full_name'))"  :disabled="disabledObj['full_name_isDisabled']"/>
							<span v-else-if="$check_field('get','full_name')">{{ form['${obj.name}'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','gender') || $check_field('add','gender') || $check_field('get','gender')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								性别:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_gender" v-model="form['gender']" placeholder="请输入性别" v-if="(form['gender'] && $check_field('set','gender')) || (!form['gender'] && $check_field('add','gender'))"  :disabled="disabledObj['gender_isDisabled']"/>
							<span v-else-if="$check_field('get','gender')">{{ form['${obj.name}'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','education') || $check_field('add','education') || $check_field('get','education')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								学历:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_education" v-model="form['education']" placeholder="请输入学历" v-if="(form['education'] && $check_field('set','education')) || (!form['education'] && $check_field('add','education'))"  :disabled="disabledObj['education_isDisabled']"/>
							<span v-else-if="$check_field('get','education')">{{ form['${obj.name}'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','university_one_is_graduated_from') || $check_field('add','university_one_is_graduated_from') || $check_field('get','university_one_is_graduated_from')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								毕业院校:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_university_one_is_graduated_from" v-model="form['university_one_is_graduated_from']" placeholder="请输入毕业院校" v-if="(form['university_one_is_graduated_from'] && $check_field('set','university_one_is_graduated_from')) || (!form['university_one_is_graduated_from'] && $check_field('add','university_one_is_graduated_from'))"  :disabled="disabledObj['university_one_is_graduated_from_isDisabled']"/>
							<span v-else-if="$check_field('get','university_one_is_graduated_from')">{{ form['${obj.name}'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','resume') || $check_field('add','resume') || $check_field('get','resume')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								简历:
							</span>
						</div>
								<!-- 文件 -->
						<input type="file" style="display: none;" id="form_file_resume" title="resume" @change="change_file($event.target.files,'resume')"/>
						<!-- 修改权限 -->
						<div class="diy_field diy_img" v-if="form['resume'] && $check_field('set','resume')">
							<label for="form_file_resume">
								<!--<span>{{form['resume']}} </span>-->
								<a :href="$fullUrl(form['resume'])" target="_blank" style="color: rgb(64, 158, 255);">点击下载</a>
							</label>
						</div>
						<!-- 添加权限 -->
						<div class="diy_field diy_img" v-else-if="!form['resume'] && $check_field('add','resume')">
							<label for="form_file_resume">
								<div class="btn_add_img">
									<span>+</span>
								</div>
							</label>
						</div>
						<!-- 查询权限 -->
						<div class="diy_field diy_img" v-else-if="$check_field('get','resume')">
							<span>{{form['resume']}} </span>
						</div>
							</div>
							<div v-if="$check_field('set','self_introduction') || $check_field('add','self_introduction') || $check_field('get','self_introduction')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								自我介绍:
							</span>
						</div>
								<!-- 多文本 -->
						<div class="diy_field diy_desc">
							<textarea id="form_self_introduction" v-model="form['self_introduction']" v-if="(form['self_introduction'] && $check_field('set','self_introduction')) || (!form['self_introduction'] && $check_field('add','self_introduction'))" :disabled="disabledObj['self_introduction_isDisabled']" />
							<span v-else-if="$check_field('get','self_introduction')">{{ form['${obj.name}'] }}</span>
						</div>
							</div>
	




				</div>
				<div class="diy_edit_submit_box row">
					<div class="col-12">
						<div class="btn_box">
							<button class="btn_submit" @click="submit()">提交</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import mixin from "@/mixins/page.js";
	export default {
		mixins: [mixin],
		components: {},
		data() {
			return {
				url_get_obj: "~/api/resume_delivery/get_obj?",
				url_add: "~/api/resume_delivery/add?",
				url_set: "~/api/resume_delivery/set?",

				// 登录权限
				oauth: {
					"signIn": true,
					"user_group": []
				},

				// 查询条件
				query: {
						"enterprise_no": 0,
							"enterprise_name": "",
							"position_name": "",
							"position_category": "",
							"user_no": 0,
							"full_name": "",
							"gender": "",
							"education": "",
							"university_one_is_graduated_from": "",
							"resume": "",
							"self_introduction": "",
						"resume_delivery_id": 0,
				},

				obj: {
						"enterprise_no": 0, // 企业编号
							"enterprise_name":  '', // 企业名称
							"position_name":  '', // 职位名称
							"position_category":  '', // 职位类别
							"user_no": 0, // 用户编号
							"full_name":  '', // 姓名
							"gender":  '', // 性别
							"education":  '', // 学历
							"university_one_is_graduated_from":  '', // 毕业院校
							"resume":  '', // 简历
							"self_introduction":  '', // 自我介绍
						"resume_delivery_id": 0,
				},

				// 表单字段
				form: {
						"enterprise_no": 0, // 企业编号
							"enterprise_name":  '', // 企业名称
							"position_name":  '', // 职位名称
							"position_category":  '', // 职位类别
							"user_no": 0, // 用户编号
							"full_name":  '', // 姓名
							"gender":  '', // 性别
							"education":  '', // 学历
							"university_one_is_graduated_from":  '', // 毕业院校
							"resume":  '', // 简历
							"self_introduction":  '', // 自我介绍
						"resume_delivery_id": 0,
				},
				disabledObj:{
						"enterprise_no_isDisabled": false,
							"enterprise_name_isDisabled": false,
							"position_name_isDisabled": false,
							"position_category_isDisabled": false,
							"user_no_isDisabled": false,
							"full_name_isDisabled": false,
							"gender_isDisabled": false,
							"education_isDisabled": false,
							"university_one_is_graduated_from_isDisabled": false,
							"resume_isDisabled": false,
							"self_introduction_isDisabled": false,
					},

						// 用户列表
				list_user_enterprise_no: [],
													// 用户列表
				list_user_user_no: [],
													
				// ID字段
				field: "resume_delivery_id",

			}
		},
		methods: {
					/**
			 * 获取招聘企业用户列表
			 */
			async get_list_user_enterprise_no() {
				// if(this.user_group !== "管理员" && this.form["enterprise_no"] === 0) {
				//     this.form["enterprise_no"] = this.user.user_id;
				// }
				var json = await this.$get("~/api/user/get_list?user_group=招聘企业");
				if(json.result && json.result.list){
					this.list_user_enterprise_no = json.result.list;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
		
				
				
				
						/**
			 * 获取注册用户用户列表
			 */
			async get_list_user_user_no() {
				// if(this.user_group !== "管理员" && this.form["user_no"] === 0) {
				//     this.form["user_no"] = this.user.user_id;
				// }
				var json = await this.$get("~/api/user/get_list?user_group=注册用户");
				if(json.result && json.result.list){
					this.list_user_user_no = json.result.list;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
					async get_user_session_user_no(){
				var _this = this;
				var json = await this.$get("~/api/user_group/get_obj?name=注册用户");
				if(json.result && json.result.obj){
					var source_table = json.result.obj.source_table;
					var user_id = _this.$store.state.user.user_id;
					if (user_id){
						var url = "~/api/"+source_table+"/get_obj?"
						this.$get(url, {"user_id":_this.$store.state.user.user_id}, function(res) {
							if (res.result && res.result.obj) {
								var arr = []
								for (let key in res.result.obj) {
									arr.push(key)
								}
								var arrForm = []
								for (let key in _this.form) {
									arrForm.push(key)
								}
								_this.form["user_no"] = user_id
								_this.disabledObj['user_no' + '_isDisabled'] = true
								for (var i=0;i<arr.length;i++){
                  if (arr[i]!=='examine_state' && arr[i]!=='examine_reply') {
                    for (var j = 0; j < arrForm.length; j++) {
                      if (arr[i] === arrForm[j]) {
                        if (arr[i] !== "user_no") {
                          _this.form[arrForm[j]] = res.result.obj[arr[i]]
                          _this.disabledObj[arrForm[j] + '_isDisabled'] = true
                          break;
                        }
                      }
                    }
                  }
								}
							}
						});
					}
				}
				else if(json.error){
					console.error(json.error);
				}
			},
	
				
				
				
				
				
				
	
			/**
			 * 修改文件
			 * @param { Object } files 上传文件对象
			 * @param { String } str 表单的属性名
			 */
			change_file(files, str) {
				var form = new FormData();
				form.append("file", files[0]);
				this.$post("~/api/resume_delivery/upload?", form, (res) => {
					if (res.result) {
						this.form[str] = res.result.url;
					} else if (res.error) {
						this.$toast(res.error.message);
					}
				});
			},

			/**
			 * 获取对象后获取缓存表单
			 * @param {Object} json
			 * @param {Object} func
			 */
			get_obj_before(param){
				var form = $.db.get("form");
				// if (form) {
        //   delete(form.examine_state)
        //   delete(form.examine_reply)
        //   this.obj = $.push(this.obj ,form);
				// 	this.form = $.push(this.form ,form);
				// }
				// var arr = []
				// for (let key in form) {
				// 	arr.push(key)
				// }
				// for (var i=0;i<arr.length;i++){
				// 	this.disabledObj[arr[i] + '_isDisabled'] = true
				// }
        if (form) {
          var arr = []
          for (let key in form) {
            arr.push(key)
          }
          var arrForm = []
          for (let key in this.form) {
            arrForm.push(key)
          }
          for (var i=0;i<arr.length;i++){
            if (arr[i]!=='examine_state' && arr[i]!=='examine_reply') {
              for (var j = 0; j < arrForm.length; j++) {
                if (arrForm[j] === arr[i]) {
                  this.form[arrForm[j]] = form[arr[i]]
                  this.obj[arrForm[j]] = form[arr[i]]
                  this.disabledObj[arrForm[j] + '_isDisabled'] = true
                  break;
                }
              }
            }
          }
        }
																						
        $.db.del("form");
				return param;
			},

			/**
			 * 获取对象后获取缓存表单
			 * @param {Object} json
			 * @param {Object} func
			 */
			get_obj_after(json ,func){
				// var form = $.db.get("form");
				// var obj = Object.assign({} ,form ,this.obj);
				// if (obj) {
        //   delete(obj.examine_state)
        //   delete(obj.examine_reply)
				// 	this.obj = $.push(this.obj ,obj);
				// }
				// if (form) {
        //   delete(form.examine_state)
        //   delete(form.examine_reply)
				// 	this.form = $.push(this.form ,form);
				// }

				if(func){
					func(json);
				}
			},

		},
		created() {
						this.get_list_user_enterprise_no();
															this.get_user_session_user_no();
					this.get_list_user_user_no();
																					},
	}
</script>

<style>




</style>
