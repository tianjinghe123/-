<template>
	<div class="diy_home diy_list diy_resume_delivery" id="diy_resume_delivery_list">
		<!-- 列表 -->
		<div class="diy_view_list list list-x" v-if="show">
			<router-link class="diy_card goods diy_list_box_wrap" v-for="(o, i) in list" :key="i"
				:to="'/resume_delivery/details?resume_delivery_id=' + o['resume_delivery_id']">
				<!-- 图片 -->
				<div class="diy_list_img_box" v-if="imgList.length" >
					<div class="diy_row" v-for="(item,index) in imgList" :key="item+index" v-show="$check_field('get',item.name,'/resume_delivery/details') && +item.is_img_list">
						<div class="diy_title diy_list_img_title">
							<span>{{item.title}}:</span>
						</div>
						<div class="diy_field diy_img">
							<img :src="$fullUrl(o[item.name])" style="width:100%;height:100%" />
						</div>
					</div>
				</div>
				<!-- 内容 -->
				<div class="diy_list_item_box">
					<div class="diy_list_item_content" v-for="(item,index) in showItemList" :key="item+index">
						<div class="diy_row" :class="{[item.name]:true}" v-if="$check_field('get',item.name,'/resume_delivery/details') && +item.is_img_list">
							<div class="diy_title">
								<span>{{item.title}}:</span>
							</div>
							<div class="diy_field diy_text">
								<span v-if="item.type == 'UID'" v-text="get_user_name(item.name,o[item.name])"></span>
								<span v-else-if="item.type == '日期'" v-text="$toTime(o[item.name],'yyyy-MM-dd')"></span>
								<span v-else-if="item.type == '时间'" v-text="$toTime(o[item.name],'hh:mm:ss')"></span>
								<span v-else-if="item.type == '日长'" v-text="$toTime(o[item.name],'yyyy-MM-dd hh:mm:ss')"></span>
								<span v-else v-text="o[item.name]"></span>
							</div>
						</div>
					</div>
				</div>
			</router-link>
		</div>
		<!-- 表格 -->
		<div class="diy_view_table" v-else>
			<table class="diy_table">
				<tr class="diy_row">
						<th class="diy_title" v-if="$check_field('get','enterprise_no')">
						企业编号
					</th>
							<th class="diy_title" v-if="$check_field('get','enterprise_name')">
						企业名称
					</th>
							<th class="diy_title" v-if="$check_field('get','position_name')">
						职位名称
					</th>
							<th class="diy_title" v-if="$check_field('get','position_category')">
						职位类别
					</th>
							<th class="diy_title" v-if="$check_field('get','user_no')">
						用户编号
					</th>
							<th class="diy_title" v-if="$check_field('get','full_name')">
						姓名
					</th>
							<th class="diy_title" v-if="$check_field('get','gender')">
						性别
					</th>
							<th class="diy_title" v-if="$check_field('get','education')">
						学历
					</th>
							<th class="diy_title" v-if="$check_field('get','university_one_is_graduated_from')">
						毕业院校
					</th>
									<th class="diy_title" v-if="$check_field('get','self_introduction')">
						自我介绍
					</th>
					</tr>
				<tr class="diy_row" v-for="(o,i) in list" :key="o+i">
						<td class="diy_field diy_uid" v-if="$check_field('get','enterprise_no')">
						<span>
							{{ get_user_name('enterprise_no',o['enterprise_no']) }}
						</span>
					</td>
							<td class="diy_field diy_text" v-if="$check_field('get','enterprise_name')">
						<span>
							{{ o["enterprise_name"] }}
						</span>
					</td>
							<td class="diy_field diy_text" v-if="$check_field('get','position_name')">
						<span>
							{{ o["position_name"] }}
						</span>
					</td>
							<td class="diy_field diy_text" v-if="$check_field('get','position_category')">
						<span>
							{{ o["position_category"] }}
						</span>
					</td>
							<td class="diy_field diy_uid" v-if="$check_field('get','user_no')">
						<span>
							{{ get_user_name('user_no',o['user_no']) }}
						</span>
					</td>
							<td class="diy_field diy_text" v-if="$check_field('get','full_name')">
						<span>
							{{ o["full_name"] }}
						</span>
					</td>
							<td class="diy_field diy_text" v-if="$check_field('get','gender')">
						<span>
							{{ o["gender"] }}
						</span>
					</td>
							<td class="diy_field diy_text" v-if="$check_field('get','education')">
						<span>
							{{ o["education"] }}
						</span>
					</td>
							<td class="diy_field diy_text" v-if="$check_field('get','university_one_is_graduated_from')">
						<span>
							{{ o["university_one_is_graduated_from"] }}
						</span>
					</td>
									<td class="diy_field diy_text" v-if="$check_field('get','self_introduction')">
						<span>
							{{ o["self_introduction"] }}
						</span>
					</td>
					</tr>
			</table>
		</div>
	</div>
</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default: function() {
					return [];
				},
			},
			show: {
				type: Boolean,
				default: function(){
					return true;
				}
			}
		},
		data() {
			return {
						imgList: [
						],
						itemList: [
								{
									title: "企业编号",
									name: "enterprise_no",
									type: "UID",
									is_img_list: "0"
								},
								{
									title: "企业名称",
									name: "enterprise_name",
									type: "文本",
									is_img_list: "0"
								},
								{
									title: "职位名称",
									name: "position_name",
									type: "文本",
									is_img_list: "0"
								},
								{
									title: "职位类别",
									name: "position_category",
									type: "文本",
									is_img_list: "0"
								},
								{
									title: "用户编号",
									name: "user_no",
									type: "UID",
									is_img_list: "0"
								},
								{
									title: "姓名",
									name: "full_name",
									type: "文本",
									is_img_list: "0"
								},
								{
									title: "性别",
									name: "gender",
									type: "文本",
									is_img_list: "0"
								},
								{
									title: "学历",
									name: "education",
									type: "文本",
									is_img_list: "0"
								},
								{
									title: "毕业院校",
									name: "university_one_is_graduated_from",
									type: "文本",
									is_img_list: "0"
								},
								{
									title: "简历",
									name: "resume",
									type: "文件",
									is_img_list: "0"
								},
						],
						richList: [
								{
									title: "自我介绍",
									name: "self_introduction",
									type: "多文本"
								},
						],
					// 用户列表
				list_user_enterprise_no: [],
									// 用户列表
				list_user_user_no: [],
										};
		},
		methods: {
			get_user_name(name,id){
				var obj = null;
					if (name == 'enterprise_no'){
					obj = this.list_user_enterprise_no.getObj({"user_id":id});
				}
									if (name == 'user_no'){
					obj = this.list_user_user_no.getObj({"user_id":id});
				}
											var ret = "";
				if(obj){
					ret = obj.nickname+"-"+obj.username;
					// if(obj.nickname){
					// 	ret = obj.nickname;
					// }
					// else{
					// 	ret = obj.username;
					// }
				}
				return ret;
			},
				/**
			 * 获取招聘企业用户列表
			 */
			async get_list_user_enterprise_no() {
				var json = await this.$get("~/api/user/get_list?user_group=招聘企业");
				if(json.result && json.result.list){
					this.list_user_enterprise_no = json.result.list;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
								/**
			 * 获取注册用户用户列表
			 */
			async get_list_user_user_no() {
				var json = await this.$get("~/api/user/get_list?user_group=注册用户");
				if(json.result && json.result.list){
					this.list_user_user_no = json.result.list;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
									},
		created() {
				this.get_list_user_enterprise_no();
								this.get_list_user_user_no();
									},
		computed:{
			showItemList(){
				let arr = [];
				let _type = ["视频","音频","文件"];
				this.itemList.forEach(item => {
					if(_type.indexOf(item.type) === -1 && !!+item.is_img_list){
						arr.push(item)
					}
				})
				return arr.slice(0,4);
			}
		}
	};
</script>

<style scoped>
	.media {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		flex-basis: 75%;
		min-height: 10rem;
	}

	.goods {
		display: flex;
		width: calc(25% - 1rem);
		margin: 0.5rem;
		padding: 0.5rem;
		flex-direction: column;
		justify-content: space-between;
		background-color: white;
		border-radius: 0.5rem;
	}

	.goods:hover {
		border: 0.2rem solid #909399;
		box-shadow: 0 0.1rem 0.3rem rgba(0, 0, 0, 0.15);
	}

	.goods:hover img {
		filter: blur(1px);
	}

	.price {
		font-size: 1rem;
		margin-right: 3px;
	}

	.price_ago {
		text-decoration: line-through;
		font-size: 0.5rem;
		color: #999;

	}

	.title {
		word-break: break-all;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		font-weight: 700;
		padding: .25rem;
	}

	.icon_cart {
		color: #FF5722;
		float: right;
	}

	@media (max-width: 992px) {

		.goods {
			width: calc(33% - 1rem);
			;
		}

	}

	@media (max-width: 768px) {

		.goods {
			width: calc(50% - 1rem);
			;
		}

	}
</style>

