package com.project.demo.dao;

import com.project.demo.dao.base.BaseMapper;
import com.project.demo.entity.RecruitmentEnterprise;

/**
 * 招聘企业：(RecruitmentEnterprise)Mapper接口
 *
 */
public interface RecruitmentEnterpriseMapper extends BaseMapper<RecruitmentEnterprise>{

}
