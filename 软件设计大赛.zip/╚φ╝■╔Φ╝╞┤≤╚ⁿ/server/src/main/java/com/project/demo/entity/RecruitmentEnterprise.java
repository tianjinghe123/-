package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 招聘企业：(RecruitmentEnterprise)表实体类
 *
 */
@TableName("`recruitment_enterprise`")
@Data
@EqualsAndHashCode(callSuper = false)
public class RecruitmentEnterprise implements Serializable {

    // RecruitmentEnterprise编号
    @TableId(value = "recruitment_enterprise_id", type = IdType.AUTO)
    private Integer recruitment_enterprise_id;

    // 企业编号
    @TableField(value = "`enterprise_no`")
    private String enterprise_no;
    // 企业名称
    @TableField(value = "`enterprise_name`")
    private String enterprise_name;
    // 负责人
    @TableField(value = "`person_in_charge`")
    private String person_in_charge;



    // 审核状态
    @TableField(value = "examine_state")
    private String examine_state;




    // 用户编号
    @TableField(value = "user_id")
    private Integer userId;



    // 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;







}
