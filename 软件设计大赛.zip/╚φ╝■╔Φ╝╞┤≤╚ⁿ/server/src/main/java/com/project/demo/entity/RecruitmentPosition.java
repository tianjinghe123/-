package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 招聘职位：(RecruitmentPosition)表实体类
 *
 */
@TableName("`recruitment_position`")
@Data
@EqualsAndHashCode(callSuper = false)
public class RecruitmentPosition implements Serializable {

    // RecruitmentPosition编号
    @TableId(value = "recruitment_position_id", type = IdType.AUTO)
    private Integer recruitment_position_id;

    // 企业编号
    @TableField(value = "`enterprise_no`")
    private Integer enterprise_no;
    // 企业名称
    @TableField(value = "`enterprise_name`")
    private String enterprise_name;
    // 职位名称
    @TableField(value = "`position_name`")
    private String position_name;
    // 职位类别
    @TableField(value = "`position_category`")
    private String position_category;
    // 地区
    @TableField(value = "`region`")
    private String region;
    // 招聘人数
    @TableField(value = "`number_of_recruiters`")
    private Integer number_of_recruiters;
    // 工作地址
    @TableField(value = "`work_address`")
    private String work_address;
    // 工作内容
    @TableField(value = "`job_content`")
    private String job_content;
    // 学历要求
    @TableField(value = "`educational_requirements`")
    private String educational_requirements;
    // 薪资待遇
    @TableField(value = "`salary`")
    private String salary;
    // 宣传图
    @TableField(value = "`publicity_map`")
    private String publicity_map;
    // 详情
    @TableField(value = "`details`")
    private String details;

    // 点击数
    @TableField(value = "hits")
    private Integer hits;

    // 点赞数
    @TableField(value = "praise_len")
    private Integer praise_len;








    // 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;







}
