package com.project.demo.dao;

import com.project.demo.dao.base.BaseMapper;
import com.project.demo.entity.InvitationForInterview;

/**
 * 面试邀请：(InvitationForInterview)Mapper接口
 *
 */
public interface InvitationForInterviewMapper extends BaseMapper<InvitationForInterview>{

}
