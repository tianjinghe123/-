package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 职位薪资：(PositionSalary)表实体类
 *
 */
@TableName("`position_salary`")
@Data
@EqualsAndHashCode(callSuper = false)
public class PositionSalary implements Serializable {

    // PositionSalary编号
    @TableId(value = "position_salary_id", type = IdType.AUTO)
    private Integer position_salary_id;

    // 年份
    @TableField(value = "`particular_year`")
    private String particular_year;
    // 职位类别
    @TableField(value = "`position_category`")
    private String position_category;
    // 平均薪资
    @TableField(value = "`average_salary`")
    private Integer average_salary;
    // 备注
    @TableField(value = "`remarks`")
    private String remarks;










    // 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;







}
