package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 简历投递：(ResumeDelivery)表实体类
 *
 */
@TableName("`resume_delivery`")
@Data
@EqualsAndHashCode(callSuper = false)
public class ResumeDelivery implements Serializable {

    // ResumeDelivery编号
    @TableId(value = "resume_delivery_id", type = IdType.AUTO)
    private Integer resume_delivery_id;

    // 企业编号
    @TableField(value = "`enterprise_no`")
    private Integer enterprise_no;
    // 企业名称
    @TableField(value = "`enterprise_name`")
    private String enterprise_name;
    // 职位名称
    @TableField(value = "`position_name`")
    private String position_name;
    // 职位类别
    @TableField(value = "`position_category`")
    private String position_category;
    // 用户编号
    @TableField(value = "`user_no`")
    private Integer user_no;
    // 姓名
    @TableField(value = "`full_name`")
    private String full_name;
    // 性别
    @TableField(value = "`gender`")
    private String gender;
    // 学历
    @TableField(value = "`education`")
    private String education;
    // 毕业院校
    @TableField(value = "`university_one_is_graduated_from`")
    private String university_one_is_graduated_from;
    // 简历
    @TableField(value = "`resume`")
    private String resume;
    // 自我介绍
    @TableField(value = "`self_introduction`")
    private String self_introduction;










    // 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;







}
