package com.project.demo.service;

import com.project.demo.entity.ResumeDelivery;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * 简历投递：(ResumeDelivery)表服务接口
 *
 */
@Service
public class ResumeDeliveryService extends BaseService<ResumeDelivery> {

}
