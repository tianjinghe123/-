package com.project.demo.dao;

import com.project.demo.dao.base.BaseMapper;
import com.project.demo.entity.PositionSalary;

/**
 * 职位薪资：(PositionSalary)Mapper接口
 *
 */
public interface PositionSalaryMapper extends BaseMapper<PositionSalary>{

}
