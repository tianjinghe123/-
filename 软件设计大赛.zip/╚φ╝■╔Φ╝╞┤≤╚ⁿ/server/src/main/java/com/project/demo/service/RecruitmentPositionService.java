package com.project.demo.service;

import com.project.demo.entity.RecruitmentPosition;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * 招聘职位：(RecruitmentPosition)表服务接口
 *
 */
@Service
public class RecruitmentPositionService extends BaseService<RecruitmentPosition> {

}
