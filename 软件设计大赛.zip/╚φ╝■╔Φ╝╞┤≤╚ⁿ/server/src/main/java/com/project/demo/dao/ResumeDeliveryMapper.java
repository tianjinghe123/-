package com.project.demo.dao;

import com.project.demo.dao.base.BaseMapper;
import com.project.demo.entity.ResumeDelivery;

/**
 * 简历投递：(ResumeDelivery)Mapper接口
 *
 */
public interface ResumeDeliveryMapper extends BaseMapper<ResumeDelivery>{

}
