package com.project.demo.service;

import com.project.demo.entity.PositionSalary;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * 职位薪资：(PositionSalary)表服务接口
 *
 */
@Service
public class PositionSalaryService extends BaseService<PositionSalary> {

}
