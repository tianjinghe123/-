package com.project.demo.service;

import com.project.demo.entity.RecruitmentEnterprise;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * 招聘企业：(RecruitmentEnterprise)表服务接口
 *
 */
@Service
public class RecruitmentEnterpriseService extends BaseService<RecruitmentEnterprise> {

}
