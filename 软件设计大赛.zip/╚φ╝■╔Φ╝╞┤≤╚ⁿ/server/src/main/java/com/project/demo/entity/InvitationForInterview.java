package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 面试邀请：(InvitationForInterview)表实体类
 *
 */
@TableName("`invitation_for_interview`")
@Data
@EqualsAndHashCode(callSuper = false)
public class InvitationForInterview implements Serializable {

    // InvitationForInterview编号
    @TableId(value = "invitation_for_interview_id", type = IdType.AUTO)
    private Integer invitation_for_interview_id;

    // 企业编号
    @TableField(value = "`enterprise_no`")
    private Integer enterprise_no;
    // 企业名称
    @TableField(value = "`enterprise_name`")
    private String enterprise_name;
    // 用户编号
    @TableField(value = "`user_no`")
    private Integer user_no;
    // 姓名
    @TableField(value = "`full_name`")
    private String full_name;
    // 职位名称
    @TableField(value = "`position_name`")
    private String position_name;
    // 面试时间
    @TableField(value = "`interview_time`")
    private Timestamp interview_time;
    // 面试地点
    @TableField(value = "`place_of_interview`")
    private String place_of_interview;
    // 携带资料
    @TableField(value = "`carrying_information`")
    private String carrying_information;



    // 审核状态
    @TableField(value = "examine_state")
    private String examine_state;



    // 审核回复
    @TableField(value = "examine_reply")
    private String examine_reply;




    // 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;







}
