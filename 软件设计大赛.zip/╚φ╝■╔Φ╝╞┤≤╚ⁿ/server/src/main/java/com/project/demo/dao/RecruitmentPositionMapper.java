package com.project.demo.dao;

import com.project.demo.dao.base.BaseMapper;
import com.project.demo.entity.RecruitmentPosition;

/**
 * 招聘职位：(RecruitmentPosition)Mapper接口
 *
 */
public interface RecruitmentPositionMapper extends BaseMapper<RecruitmentPosition>{

}
