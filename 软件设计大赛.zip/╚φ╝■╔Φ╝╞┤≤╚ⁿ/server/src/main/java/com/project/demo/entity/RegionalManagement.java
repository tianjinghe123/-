package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 地区管理：(RegionalManagement)表实体类
 *
 */
@TableName("`regional_management`")
@Data
@EqualsAndHashCode(callSuper = false)
public class RegionalManagement implements Serializable {

    // RegionalManagement编号
    @TableId(value = "regional_management_id", type = IdType.AUTO)
    private Integer regional_management_id;

    // 地区
    @TableField(value = "`region`")
    private String region;










    // 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;







}
