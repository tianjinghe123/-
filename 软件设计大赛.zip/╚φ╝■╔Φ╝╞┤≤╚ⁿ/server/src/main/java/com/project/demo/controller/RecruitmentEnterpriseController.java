package com.project.demo.controller;

import com.project.demo.entity.RecruitmentEnterprise;
import com.project.demo.service.RecruitmentEnterpriseService;
import com.project.demo.controller.base.BaseController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.*;

/**
 * 招聘企业：(RecruitmentEnterprise)表控制层
 *
 */
@RestController
@RequestMapping("/recruitment_enterprise")
public class RecruitmentEnterpriseController extends BaseController<RecruitmentEnterprise, RecruitmentEnterpriseService> {

    /**
     * 招聘企业对象
     */
    @Autowired
    public RecruitmentEnterpriseController(RecruitmentEnterpriseService service) {
        setService(service);
    }


    @PostMapping("/add")
    @Transactional
    public Map<String, Object> add(HttpServletRequest request) throws IOException {
        Map<String,Object> paramMap = service.readBody(request.getReader());
        Map<String, String> mapenterprise_no = new HashMap<>();
        mapenterprise_no.put("enterprise_no",String.valueOf(paramMap.get("enterprise_no")));
        List listenterprise_no = service.selectBaseList(service.select(mapenterprise_no, new HashMap<>()));
        if (listenterprise_no.size()>0){
            return error(30000, "字段企业编号内容不能重复");
        }
        this.addMap(paramMap);
        return success(1);
    }

}
