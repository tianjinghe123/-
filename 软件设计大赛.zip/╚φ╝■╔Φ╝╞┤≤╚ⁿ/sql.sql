DROP TABLE IF EXISTS `slides`;
CREATE TABLE `slides` (
  `slides_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '轮播图ID：',
  `title` varchar(64) DEFAULT NULL COMMENT '标题：',
  `content` varchar(255) DEFAULT NULL COMMENT '内容：',
  `url` varchar(255) DEFAULT NULL COMMENT '链接：',
  `img` varchar(255) DEFAULT NULL COMMENT '轮播图：',
  `hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点击量：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`slides_id`) USING BTREE
  `user_group` varchar(64) DEFAULT NULL COMMENT '用户组：',
  `mod_name` varchar(64) DEFAULT NULL COMMENT '模块名：',
  `table_name` varchar(64) DEFAULT NULL COMMENT '表名：',
  `page_title` varchar(255) DEFAULT NULL COMMENT '页面标题：',
  `path` varchar(255) DEFAULT NULL COMMENT '路由路径：',
  `position` varchar(32) DEFAULT NULL COMMENT '位置：',
  `mode` varchar(32) NOT NULL DEFAULT '_blank' COMMENT '跳转方式：',
  `add` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否可增加：',
  `del` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否可删除：',
  `set` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否可修改：',
  `get` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否可查看：',
  `field_add` text COMMENT '添加字段：',
  `field_set` text COMMENT '修改字段：',
  `field_get` text COMMENT '查询字段：',
  `table_nav_name` varchar(500) DEFAULT NULL COMMENT '跨表导航名称：',
  `table_nav` varchar(500) DEFAULT NULL COMMENT '跨表导航：',
  `option` text COMMENT '配置：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`auth_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户权限管理';
DROP TABLE IF EXISTS `upload`;
CREATE TABLE `upload` (
  `upload_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '上传ID',
  `name` varchar(64) DEFAULT NULL COMMENT '文件名',
  `path` varchar(255) DEFAULT NULL COMMENT '访问路径',
  `file` varchar(255) DEFAULT NULL COMMENT '文件路径',
  `display` varchar(255) DEFAULT NULL COMMENT '显示顺序',
  `father_id` int(11) DEFAULT '0' COMMENT '父级ID',
  `dir` varchar(255) DEFAULT NULL COMMENT '文件夹',
  `type` varchar(32) DEFAULT NULL COMMENT '文件类型',
  PRIMARY KEY (`upload_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件上传';
insert into `upload` values ('1','movie.mp4','/upload/movie.mp4','',null,'0',null,'video');
DROP TABLE IF EXISTS `user_group`;
CREATE TABLE `user_group` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组ID：[0,8388607]',
  `display` smallint(4) unsigned NOT NULL DEFAULT '100' COMMENT '显示顺序：[0,1000]',
  `name` varchar(16) NOT NULL DEFAULT '' COMMENT '名称：[0,16]',
  `description` varchar(255) DEFAULT NULL COMMENT '描述：[0,255]描述该用户组的特点或权限范围',
  `source_table` varchar(255) DEFAULT NULL COMMENT '来源表：',
  `source_field` varchar(255) DEFAULT NULL COMMENT '来源字段：',
  `source_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来源ID：',
  `register` smallint(1) unsigned DEFAULT '0' COMMENT '注册位置:',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`group_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组：用于用户前端身份和鉴权';
DROP TABLE IF EXISTS `article_type`;
CREATE TABLE `article_type` (
  `type_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID：[0,10000]',
  `display` smallint(4) unsigned NOT NULL DEFAULT '100' COMMENT '显示顺序：[0,1000]决定分类显示的先后顺序',
  `name` varchar(16) NOT NULL DEFAULT '' COMMENT '分类名称：[2,16]',
  `father_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID：[0,32767]',
  `description` varchar(255) DEFAULT NULL COMMENT '描述：[0,255]描述该分类的作用',
  `icon` text COMMENT '分类图标：',
  `url` varchar(255) DEFAULT NULL COMMENT '外链地址：[0,255]如果该分类是跳转到其他网站的情况下，就在该URL上设置',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`type_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文章分类';
DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `article_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章id：[0,8388607]',
  `title` varchar(125) NOT NULL DEFAULT '' COMMENT '标题：[0,125]用于文章和html的title标签中',
  `type` varchar(64) NOT NULL DEFAULT '0' COMMENT '文章分类：[0,1000]用来搜索指定类型的文章',
  `hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点击数：[0,1000000000]访问这篇文章的人次',
  `praise_len` int(11) NOT NULL DEFAULT '0' COMMENT '点赞数',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  `source` varchar(255) DEFAULT NULL COMMENT '来源：[0,255]文章的出处',
  `url` varchar(255) DEFAULT NULL COMMENT '来源地址：[0,255]用于跳转到发布该文章的网站',
  `tag` varchar(255) DEFAULT NULL COMMENT '标签：[0,255]用于标注文章所属相关内容，多个标签用空格隔开',
  `content` longtext COMMENT '正文：文章的主体内容',
  `img` varchar(255) DEFAULT NULL COMMENT '封面图',
  `description` text COMMENT '文章描述',
  PRIMARY KEY (`article_id`,`title`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文章：用于内容管理系统的文章';
DROP TABLE IF EXISTS `praise`;
CREATE TABLE `praise` (
  `praise_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '点赞ID：',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点赞人：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  `source_table` varchar(255) DEFAULT NULL COMMENT '来源表：',
  `source_field` varchar(255) DEFAULT NULL COMMENT '来源字段：',
  `source_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来源ID：',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '点赞状态:1为点赞，0已取消',
  PRIMARY KEY (`praise_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='点赞';
DROP TABLE IF EXISTS `access_token`;
CREATE TABLE `access_token` (
  `token_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '临时访问牌ID',
  `token` varchar(64) DEFAULT NULL COMMENT '临时访问牌',
  `info` text,
  `maxage` int(2) NOT NULL DEFAULT '2' COMMENT '最大寿命：默认2小时',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户编号:',
  PRIMARY KEY (`token_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='登陆访问时长';
insert into `access_token` values ('57','5accf85cb6a7f06f0aa2968deadaec1b',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('58','46ff1d4d07714f046ba07b34bffe0af9',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('59','ed9d6cba9826fda1beafcd9326be7a86',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('60','c99763c1833ea0785d9e2b81da3fd28f',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('61','33fbfaccd6d1cb9143e4129bd919d4b0',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('62','493e13da5f293ba67a56a0fe3e1fa6cf',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('63','c4b48e9e2160db09c703041a8fee0a1f',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('64','d13cdaefd3823c360c959a02a262f71d',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('65','6c6ff426fd77ea5a2025ce5ed2e42c8a',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('66','80930065a61ffcdd5cbb75f60932973c',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('67','94114763cf2e3b020495d8a27096d4ef',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('68','761052c551c97c9317bc3aa475c85b84',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('69','7c44ef14131a0ba7c16aa16cef104065',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('70','96380f3d9542c80d04bdade1cf7635a5',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('71','bfdc7acfcbf5763fda81945b60961222',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('72','170a598e51ae8ae2badde20a42fe171d',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('73','c82c357488c75926a92d8a9608d4b367',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('74','4d35290c023f407a820f37dbbb1ceb09',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('75','8d19162776682b695c0f62f3c7a92fec',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('76','a7ea2cdc9a2be179e19200e593ad5a69',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('77','c79a554f9832adc01f19682c5d576bc4',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('78','1c7d95001fa09951a679841c8100ad1f',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('79','776da1bcdd01ddb3cbf0a37fa13fc5b0',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('80','d336e88e57c329d0166931292c1fac41',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('81','37a40f526a6c82fc6110b512802d35bf',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('82','691ad331771f4109206d58aeee572371',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('83','9942e458886219960d3344b4a6a6fbec',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('84','e9939a8b7ccf9f548f0bbb5664981f96',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('85','f5b27912060d1909bef61fab9d96faae',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('86','7c5888682f1d449eb1b62f0054a79fbf',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('87','00dfdc6ac21c4a9da80fd71c990764d1',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('88','3cce592bc72840ab932ce96d85a194da',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('89','43fdaa989a644ad683ef4b4d488e8629',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('90','d6a3cecadacff0dbd6b43b25372cc2a2',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('91','5570bc5b07b3589f4ef8553bd46eb0d1',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('92','5570bc5b07b3589f4ef8553bd46eb0d1',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('93','26c553bd2ee2ab6605d18dfd310d85f9',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('94','3fd52f81236ed2c37ff91a6696d4e47a',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('95','893332e9ee67d60d8312b3700c58a359',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('96','b7844068ade535b2e517df4a40948703',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('97','179b37a5e1893c3af6b946bd5a1c8625',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('98','3a47b8a040a83ebbc9194cb255dc668c',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('99','afa60196afb77dcc2b520ed13a817560',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('100','7fc6d9b324f8c0a3a1784d04ef132692',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
insert into `access_token` values ('101','84e31b291f2bde6b7ceb27af5fe8eee3',null,'2','2023-05-30 18:21:49.0','2023-05-30 18:21:49.0','1');
DROP TABLE IF EXISTS `hits`;
CREATE TABLE `hits` (
  `hits_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '点赞ID：',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点赞人：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  `source_table` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '来源表：',
  `source_field` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '来源字段：',
  `source_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来源ID：',
  PRIMARY KEY (`hits_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='用户点击';
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `comment_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '评论ID：',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '评论人ID：',
  `reply_to_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '回复评论ID：空为0',
  `content` longtext COMMENT '内容：',
  `nickname` varchar(255) DEFAULT NULL COMMENT '昵称：',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像地址：[0,255]',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  `source_table` varchar(255) DEFAULT NULL COMMENT '来源表：',
  `source_field` varchar(255) DEFAULT NULL COMMENT '来源字段：',
  `source_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来源ID：',
  PRIMARY KEY (`comment_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='评论';
DROP TABLE IF EXISTS `collect`;
CREATE TABLE `collect` (
  `collect_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '收藏ID：',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏人ID：',
  `source_table` varchar(255) DEFAULT NULL COMMENT '来源表：',
  `source_field` varchar(255) DEFAULT NULL COMMENT '来源字段：',
  `source_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来源ID：',
  `title` varchar(255) DEFAULT NULL COMMENT '标题：',
  `img` varchar(255) DEFAULT NULL COMMENT '封面：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`collect_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='收藏';
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID：[0,8388607]用户获取其他与用户相关的数据',
  `state` smallint(1) unsigned NOT NULL DEFAULT '1' COMMENT '账户状态：[0,10](1可用|2异常|3已冻结|4已注销)',
  `user_group` varchar(32) DEFAULT NULL COMMENT '所在用户组：[0,32767]决定用户身份和权限',
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '上次登录时间：',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机号码：[0,11]用户的手机号码，用于找回密码时或登录时',
  `phone_state` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '手机认证：[0,1](0未认证|1审核中|2已认证)',
  `username` varchar(16) NOT NULL DEFAULT '' COMMENT '用户名：[0,16]用户登录时所用的账户名称',
  `nickname` varchar(16) DEFAULT '' COMMENT '昵称：[0,16]',
  `password` varchar(64) NOT NULL DEFAULT '' COMMENT '密码：[0,32]用户登录所需的密码，由6-16位数字或英文组成',
  `email` varchar(64) DEFAULT '' COMMENT '邮箱：[0,64]用户的邮箱，用于找回密码时或登录时',
  `email_state` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '邮箱认证：[0,1](0未认证|1审核中|2已认证)',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像地址：[0,255]',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户账户：用于保存用户登录信息';
insert into `user` values ('1','1','管理员','2023-05-04 16:42:42.0',null,'0','admin','admin','bfd59291e825b5f2bbf1eb76569f8fe7','','0','/api/upload/admin_avatar.jpg','2023-05-30 17:35:13.0');
DROP TABLE IF EXISTS `registered_user`;
CREATE TABLE `registered_user`(registered_user_id int(11) NOT NULL AUTO_INCREMENT COMMENT '注册用户ID',
`user_no` varchar(64) NOT NULL UNIQUE comment '用户编号',
`full_name` varchar(64) comment '姓名',
`gender` varchar(64) comment '性别',
`education` varchar(64) comment '学历',
`university_one_is_graduated_from` varchar(64) comment '毕业院校',
`examine_state` varchar(16) DEFAULT '已通过' NOT NULL comment '审核状态',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`user_id` int(11) DEFAULT '0' NOT NULL comment '用户ID',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
PRIMARY KEY (registered_user_id))ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '注册用户';

DROP TABLE IF EXISTS `recruitment_enterprise`;
CREATE TABLE `recruitment_enterprise`(recruitment_enterprise_id int(11) NOT NULL AUTO_INCREMENT COMMENT '招聘企业ID',
`enterprise_no` varchar(64) NOT NULL UNIQUE comment '企业编号',
`enterprise_name` varchar(64) comment '企业名称',
`person_in_charge` varchar(64) comment '负责人',
`examine_state` varchar(16) DEFAULT '未审核' NOT NULL comment '审核状态',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`user_id` int(11) DEFAULT '0' NOT NULL comment '用户ID',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
PRIMARY KEY (recruitment_enterprise_id))ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '招聘企业';

DROP TABLE IF EXISTS `position_classification`;
CREATE TABLE `position_classification`(position_classification_id int(11) NOT NULL AUTO_INCREMENT COMMENT '职位分类ID',
`position_category` varchar(64) comment '职位类别',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
PRIMARY KEY (position_classification_id))ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '职位分类';
insert into `position_classification` values (1,'职位类别1',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `position_classification` values (2,'职位类别2',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `position_classification` values (3,'职位类别3',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `position_classification` values (4,'职位类别4',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `position_classification` values (5,'职位类别5',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `position_classification` values (6,'职位类别6',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `position_classification` values (7,'职位类别7',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `position_classification` values (8,'职位类别8',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');

DROP TABLE IF EXISTS `regional_management`;
CREATE TABLE `regional_management`(regional_management_id int(11) NOT NULL AUTO_INCREMENT COMMENT '地区管理ID',
`region` varchar(64) comment '地区',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
PRIMARY KEY (regional_management_id))ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '地区管理';
insert into `regional_management` values (1,'地区1',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `regional_management` values (2,'地区2',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `regional_management` values (3,'地区3',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `regional_management` values (4,'地区4',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `regional_management` values (5,'地区5',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `regional_management` values (6,'地区6',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `regional_management` values (7,'地区7',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `regional_management` values (8,'地区8',0,'2023-07-28 11:31:04','2023-07-28 11:31:04');

DROP TABLE IF EXISTS `recruitment_position`;
CREATE TABLE `recruitment_position`(recruitment_position_id int(11) NOT NULL AUTO_INCREMENT COMMENT '招聘职位ID',
`enterprise_no` int(11) DEFAULT 0 comment '企业编号',
`enterprise_name` varchar(64) comment '企业名称',
`position_name` varchar(64) comment '职位名称',
`position_category` varchar(64) comment '职位类别',
`region` varchar(64) comment '地区',
`number_of_recruiters` int(11) DEFAULT 0 comment '招聘人数',
`work_address` varchar(64) comment '工作地址',
`job_content` text comment '工作内容',
`educational_requirements` text comment '学历要求',
`salary` text comment '薪资待遇',
`publicity_map` varchar(255) comment '宣传图',
`details` longtext comment '详情',
`hits` int(11) DEFAULT 0 NOT NULL comment '点击数',
`praise_len` int(11) DEFAULT 0 NOT NULL comment '点赞数',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
PRIMARY KEY (recruitment_position_id))ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '招聘职位';
insert into `recruitment_position` values (1,0,'企业名称1','职位名称1','职位类别1','地区1',1,'工作地址1','工作内容1','学历要求1','薪资待遇1','/api/upload/1575397910399418368.jpg','此处可上传文字、图片、视频、超链接、表格等内容区1',235,691,0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `recruitment_position` values (2,0,'企业名称2','职位名称2','职位类别2','地区2',2,'工作地址2','工作内容2','学历要求2','薪资待遇2','/api/upload/1575398019988193281.jpg','此处可上传文字、图片、视频、超链接、表格等内容区2',891,303,0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `recruitment_position` values (3,0,'企业名称3','职位名称3','职位类别3','地区3',3,'工作地址3','工作内容3','学历要求3','薪资待遇3','/api/upload/1575397845459009536.jpg','此处可上传文字、图片、视频、超链接、表格等内容区3',262,773,0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `recruitment_position` values (4,0,'企业名称4','职位名称4','职位类别4','地区4',4,'工作地址4','工作内容4','学历要求4','薪资待遇4','/api/upload/1575397763896573953.jpg','此处可上传文字、图片、视频、超链接、表格等内容区4',665,428,0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `recruitment_position` values (5,0,'企业名称5','职位名称5','职位类别5','地区5',5,'工作地址5','工作内容5','学历要求5','薪资待遇5','/api/upload/1575397962840801281.jpg','此处可上传文字、图片、视频、超链接、表格等内容区5',825,865,0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `recruitment_position` values (6,0,'企业名称6','职位名称6','职位类别6','地区6',6,'工作地址6','工作内容6','学历要求6','薪资待遇6','/api/upload/1575397556257554432.jpg','此处可上传文字、图片、视频、超链接、表格等内容区6',242,933,0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `recruitment_position` values (7,0,'企业名称7','职位名称7','职位类别7','地区7',7,'工作地址7','工作内容7','学历要求7','薪资待遇7','/api/upload/1575397648104423424.jpg','此处可上传文字、图片、视频、超链接、表格等内容区7',611,167,0,'2023-07-28 11:31:04','2023-07-28 11:31:04');
insert into `recruitment_position` values (8,0,'企业名称8','职位名称8','职位类别8','地区8',8,'工作地址8','工作内容8','学历要求8','薪资待遇8','/api/upload/1575397714261180417.jpg','此处可上传文字、图片、视频、超链接、表格等内容区8',389,995,0,'2023-07-28 11:31:04','2023-07-28 11:31:04');

DROP TABLE IF EXISTS `resume_delivery`;
CREATE TABLE `resume_delivery`(resume_delivery_id int(11) NOT NULL AUTO_INCREMENT COMMENT '简历投递ID',
`enterprise_no` int(11) DEFAULT 0 comment '企业编号',
`enterprise_name` varchar(64) comment '企业名称',
`position_name` varchar(64) comment '职位名称',
`position_category` varchar(64) comment '职位类别',
`user_no` int(11) DEFAULT 0 comment '用户编号',
`full_name` varchar(64) comment '姓名',
`gender` varchar(64) comment '性别',
`education` varchar(64) comment '学历',
`university_one_is_graduated_from` varchar(64) comment '毕业院校',
`resume` varchar(255) comment '简历',
`self_introduction` text comment '自我介绍',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
PRIMARY KEY (resume_delivery_id))ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '简历投递';
insert into `resume_delivery` values (1,0,'企业名称1','职位名称1','职位类别1',0,'姓名1','性别1','学历1','毕业院校1','','自我介绍1',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `resume_delivery` values (2,0,'企业名称2','职位名称2','职位类别2',0,'姓名2','性别2','学历2','毕业院校2','','自我介绍2',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `resume_delivery` values (3,0,'企业名称3','职位名称3','职位类别3',0,'姓名3','性别3','学历3','毕业院校3','','自我介绍3',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `resume_delivery` values (4,0,'企业名称4','职位名称4','职位类别4',0,'姓名4','性别4','学历4','毕业院校4','','自我介绍4',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `resume_delivery` values (5,0,'企业名称5','职位名称5','职位类别5',0,'姓名5','性别5','学历5','毕业院校5','','自我介绍5',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `resume_delivery` values (6,0,'企业名称6','职位名称6','职位类别6',0,'姓名6','性别6','学历6','毕业院校6','','自我介绍6',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `resume_delivery` values (7,0,'企业名称7','职位名称7','职位类别7',0,'姓名7','性别7','学历7','毕业院校7','','自我介绍7',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `resume_delivery` values (8,0,'企业名称8','职位名称8','职位类别8',0,'姓名8','性别8','学历8','毕业院校8','','自我介绍8',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');

DROP TABLE IF EXISTS `invitation_for_interview`;
CREATE TABLE `invitation_for_interview`(invitation_for_interview_id int(11) NOT NULL AUTO_INCREMENT COMMENT '面试邀请ID',
`enterprise_no` int(11) DEFAULT 0 comment '企业编号',
`enterprise_name` varchar(64) comment '企业名称',
`user_no` int(11) DEFAULT 0 comment '用户编号',
`full_name` varchar(64) comment '姓名',
`position_name` varchar(64) comment '职位名称',
`interview_time` datetime comment '面试时间',
`place_of_interview` varchar(64) comment '面试地点',
`carrying_information` text comment '携带资料',
`examine_state` varchar(16) DEFAULT '未审核' NOT NULL comment '审核状态',
`examine_reply` varchar(16) DEFAULT '' comment '审核回复',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
PRIMARY KEY (invitation_for_interview_id))ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '面试邀请';
insert into `invitation_for_interview` values (1,0,'企业名称1',0,'姓名1','职位名称1','2023-07-28 11:31:05','面试地点1','携带资料1','未审核','',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `invitation_for_interview` values (2,0,'企业名称2',0,'姓名2','职位名称2','2023-07-28 11:31:05','面试地点2','携带资料2','未审核','',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `invitation_for_interview` values (3,0,'企业名称3',0,'姓名3','职位名称3','2023-07-28 11:31:05','面试地点3','携带资料3','未审核','',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `invitation_for_interview` values (4,0,'企业名称4',0,'姓名4','职位名称4','2023-07-28 11:31:05','面试地点4','携带资料4','未审核','',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `invitation_for_interview` values (5,0,'企业名称5',0,'姓名5','职位名称5','2023-07-28 11:31:05','面试地点5','携带资料5','未审核','',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `invitation_for_interview` values (6,0,'企业名称6',0,'姓名6','职位名称6','2023-07-28 11:31:05','面试地点6','携带资料6','未审核','',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `invitation_for_interview` values (7,0,'企业名称7',0,'姓名7','职位名称7','2023-07-28 11:31:05','面试地点7','携带资料7','未审核','',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `invitation_for_interview` values (8,0,'企业名称8',0,'姓名8','职位名称8','2023-07-28 11:31:05','面试地点8','携带资料8','未审核','',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');

DROP TABLE IF EXISTS `position_salary`;
CREATE TABLE `position_salary`(position_salary_id int(11) NOT NULL AUTO_INCREMENT COMMENT '职位薪资ID',
`particular_year` varchar(64) comment '年份',
`position_category` varchar(64) comment '职位类别',
`average_salary` int(11) DEFAULT 0 comment '平均薪资',
`remarks` text comment '备注',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
PRIMARY KEY (position_salary_id))ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '职位薪资';
insert into `position_salary` values (1,'年份1','职位类别1',1,'备注1',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `position_salary` values (2,'年份2','职位类别2',2,'备注2',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `position_salary` values (3,'年份3','职位类别3',3,'备注3',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `position_salary` values (4,'年份4','职位类别4',4,'备注4',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `position_salary` values (5,'年份5','职位类别5',5,'备注5',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `position_salary` values (6,'年份6','职位类别6',6,'备注6',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `position_salary` values (7,'年份7','职位类别7',7,'备注7',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `position_salary` values (8,'年份8','职位类别8',8,'备注8',0,'2023-07-28 11:31:05','2023-07-28 11:31:05');
insert into `user_group` values ('1','100','管理员',null,'','','0','0','2023-07-28 11:31:05.0','2023-07-28 11:31:05.0');
insert into `user_group` values ('2','100','游客',null,'','','0','0','2023-07-28 11:31:05.0','2023-07-28 11:31:05.0');
insert into `user_group` values ('3','100','注册用户',null,'registered_user','registered_user_id','0','3','2023-07-28 11:31:05.0','2023-07-28 11:31:05.0');
insert into `user_group` values ('4','100','招聘企业',null,'recruitment_enterprise','recruitment_enterprise_id','0','3','2023-07-28 11:31:05.0','2023-07-28 11:31:05.0');
insert into `slides` values ('1','轮播图1','内容1','/article/details?article=1','/api/upload/1575396758849060865.jpg','537','2023-07-28 11:31:05.0','2023-07-28 11:31:05.0');
insert into `slides` values ('2','轮播图2','内容2','/article/details?article=2','/api/upload/1599967239379877888.jpg','473','2023-07-28 11:31:05.0','2023-07-28 11:31:05.0');
insert into `slides` values ('3','轮播图3','内容3','/article/details?article=3','/api/upload/1575396868240703489.jpg','395','2023-07-28 11:31:05.0','2023-07-28 11:31:05.0');
insert into `article_type` values ('1','100','招聘','0',null,null,null,'2023-07-28 11:31:05.0','2023-07-28 11:31:05.0');
