<template>
	<el-main class="bg edit_wrap">
		<el-form ref="form" :model="form" status-icon label-width="120px" v-if="is_view()">

							<el-col v-if="user_group === '管理员' || $check_field('get','enterprise_no') || $check_field('add','enterprise_no') || $check_field('set','enterprise_no')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="企业编号" prop="enterprise_no">
																		<div v-if="user_group !== '管理员'">
							{{ get_user_session_enterprise_no(form['enterprise_no']) }}
							<!--<el-input id="business_name" v-model="form['enterprise_no']" placeholder="请输入企业编号"-->
							<!--v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','enterprise_no')) || (!form['recruitment_position_id'] && $check_field('add','enterprise_no'))" :disabled="disabledObj['enterprise_no_isDisabled']"></el-input>-->
							<!--<div v-else-if="$check_field('get','enterprise_no')">{{form['enterprise_no']}}</div>-->
							<el-select v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','enterprise_no')) || (!form['recruitment_position_id'] && $check_field('add','enterprise_no'))" id="enterprise_no" v-model="form['enterprise_no']" :disabled="disabledObj['enterprise_no_isDisabled']">
								<el-option v-for="o in list_user_enterprise_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
										   :value="o['user_id']">
								</el-option>
							</el-select>
							<el-select v-else-if="$check_field('get','enterprise_no')" id="enterprise_no" v-model="form['enterprise_no']" :disabled="true">
								<el-option v-for="o in list_user_enterprise_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
										   :value="o['user_id']">
								</el-option>
							</el-select>
						</div>
						<el-select v-else id="enterprise_no" v-model="form['enterprise_no']" :disabled="disabledObj['enterprise_no_isDisabled']">
							<el-option v-for="o in list_user_enterprise_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
																</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','enterprise_name') || $check_field('add','enterprise_name') || $check_field('set','enterprise_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="企业名称" prop="enterprise_name">
												<el-input id="enterprise_name" v-model="form['enterprise_name']" placeholder="请输入企业名称"
							  v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','enterprise_name')) || (!form['recruitment_position_id'] && $check_field('add','enterprise_name'))" :disabled="disabledObj['enterprise_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','enterprise_name')">{{form['enterprise_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','position_name') || $check_field('add','position_name') || $check_field('set','position_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="职位名称" prop="position_name">
												<el-input id="position_name" v-model="form['position_name']" placeholder="请输入职位名称"
							  v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','position_name')) || (!form['recruitment_position_id'] && $check_field('add','position_name'))" :disabled="disabledObj['position_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','position_name')">{{form['position_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','position_category') || $check_field('add','position_category') || $check_field('set','position_category')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="职位类别" prop="position_category">
								<el-select id="position_category" v-model="form['position_category']"
						v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','position_category')) || (!form['recruitment_position_id'] && $check_field('add','position_category'))">
						<el-option v-for="o in list_position_category" :key="o['position_category']" :label="o['position_category']"
							:value="o['position_category']">
						</el-option>
					</el-select>
					<div v-else-if="$check_field('get','position_category')">{{form['position_category']}}</div>
							</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','region') || $check_field('add','region') || $check_field('set','region')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="地区" prop="region">
								<el-select id="region" v-model="form['region']"
						v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','region')) || (!form['recruitment_position_id'] && $check_field('add','region'))">
						<el-option v-for="o in list_region" :key="o['region']" :label="o['region']"
							:value="o['region']">
						</el-option>
					</el-select>
					<div v-else-if="$check_field('get','region')">{{form['region']}}</div>
							</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','number_of_recruiters') || $check_field('add','number_of_recruiters') || $check_field('set','number_of_recruiters')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="招聘人数" prop="number_of_recruiters">
								<el-input-number id="number_of_recruiters" v-model.number="form['number_of_recruiters']"
						v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','number_of_recruiters')) || (!form['recruitment_position_id'] && $check_field('add','number_of_recruiters'))" :disabled="disabledObj['number_of_recruiters_isDisabled']"></el-input-number>
					<div v-else-if="$check_field('get','number_of_recruiters')">{{form['number_of_recruiters']}}</div>
							</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','work_address') || $check_field('add','work_address') || $check_field('set','work_address')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="工作地址" prop="work_address">
												<el-input id="work_address" v-model="form['work_address']" placeholder="请输入工作地址"
							  v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','work_address')) || (!form['recruitment_position_id'] && $check_field('add','work_address'))" :disabled="disabledObj['work_address_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','work_address')">{{form['work_address']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','job_content') || $check_field('add','job_content') || $check_field('set','job_content')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="工作内容" prop="job_content">
								<el-input type="textarea" id="job_content" v-model="form['job_content']" placeholder="请输入工作内容"
						v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','job_content')) || (!form['recruitment_position_id'] && $check_field('add','job_content'))" :disabled="disabledObj['job_content_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','job_content')">{{form['job_content']}}</div>
							</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','educational_requirements') || $check_field('add','educational_requirements') || $check_field('set','educational_requirements')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="学历要求" prop="educational_requirements">
								<el-input type="textarea" id="educational_requirements" v-model="form['educational_requirements']" placeholder="请输入学历要求"
						v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','educational_requirements')) || (!form['recruitment_position_id'] && $check_field('add','educational_requirements'))" :disabled="disabledObj['educational_requirements_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','educational_requirements')">{{form['educational_requirements']}}</div>
							</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','salary') || $check_field('add','salary') || $check_field('set','salary')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="薪资待遇" prop="salary">
								<el-input type="textarea" id="salary" v-model="form['salary']" placeholder="请输入薪资待遇"
						v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','salary')) || (!form['recruitment_position_id'] && $check_field('add','salary'))" :disabled="disabledObj['salary_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','salary')">{{form['salary']}}</div>
							</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','publicity_map') || $check_field('add','publicity_map') || $check_field('set','publicity_map')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="宣传图" prop="publicity_map">
								<el-upload :disabled="disabledObj['publicity_map_isDisabled']" id="publicity_map" class="avatar-uploader" drag
						accept="image/gif, image/jpeg, image/png, image/jpg" action="" :http-request="upload_publicity_map"
						:show-file-list="false" v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','publicity_map')) || (!form['recruitment_position_id'] && $check_field('add','publicity_map'))">
						<img v-if="form['publicity_map']" :src="$fullUrl(form['publicity_map'])" class="avatar">
						<i v-else class="el-icon-plus avatar-uploader-icon"></i>
					</el-upload>
					<el-image v-else-if="$check_field('get','publicity_map')" style="width: 100px; height: 100px"
						:src="$fullUrl(form['publicity_map'])" :preview-src-list="[$fullUrl(form['publicity_map'])]">
						<div slot="error" class="image-slot">
							<img src="../../../public/img/error.png" style="width: 90px; height: 90px" />
						</div>
					</el-image>
							</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','details') || $check_field('add','details') || $check_field('set','details')" :xs="24" :sm="24" :lg="24" class="el_form_editor_warp">
				<el-form-item label="详情" prop="details">
					<quill-editor v-model.number="form['details']"
						v-if="user_group === '管理员' || (form['recruitment_position_id'] && $check_field('set','details')) || (!form['recruitment_position_id'] && $check_field('add','details')) ">
					</quill-editor>
					<div v-else-if="$check_field('get','details')" v-html="form['details']"></div>
				</el-form-item>
			</el-col>
					
	
	
	
	
	
	
			<el-col :xs="24" :sm="12" :lg="8" class="el_form_btn_warp">
				<el-form-item>
					<el-button type="primary" @click="submit()">提交</el-button>
					<el-button @click="cancel()">取消</el-button>
				</el-form-item>
			</el-col>

		</el-form>
	</el-main>
</template>

<script>
	import mixin from "@/mixins/page.js";

	export default {
		mixins: [mixin],
		data() {
			return {
				field: "recruitment_position_id",
				url_add: "~/api/recruitment_position/add?",
				url_set: "~/api/recruitment_position/set?",
				url_get_obj: "~/api/recruitment_position/get_obj?",
				url_upload: "~/api/recruitment_position/upload?",

				query: {
					"recruitment_position_id": 0,
				},

				form: {
								"enterprise_no": 0, // 企业编号
										"enterprise_name":  '', // 企业名称
										"position_name":  '', // 职位名称
										"position_category":  '', // 职位类别
										"region":  '', // 地区
										"number_of_recruiters":  0, // 招聘人数
										"work_address":  '', // 工作地址
										"job_content":  '', // 工作内容
										"educational_requirements":  '', // 学历要求
										"salary":  '', // 薪资待遇
										"publicity_map":  '', // 宣传图
										"details":  '', // 详情
											"recruitment_position_id": 0, // ID
						
				},
				disabledObj:{
								"enterprise_no_isDisabled": false,
										"enterprise_name_isDisabled": false,
										"position_name_isDisabled": false,
										"position_category_isDisabled": false,
										"region_isDisabled": false,
					          			"number_of_recruiters_isDisabled": false,
										"work_address_isDisabled": false,
										"job_content_isDisabled": false,
										"educational_requirements_isDisabled": false,
										"salary_isDisabled": false,
										"publicity_map_isDisabled": false,
										"details_isDisabled": false,
										},

	
					// 用户列表
				list_user_enterprise_no: [],
						// 用户组
				group_user_enterprise_no: "",
				
		
						// 职位类别选项列表
				list_position_category: [""],
	
						// 地区选项列表
				list_region: [""],
	
		
		
		
		
		
		
		
	
			}
		},
		methods: {


	
	
				/**
			 * 获取招聘企业用户列表
			 */
			async get_list_user_enterprise_no() {
                // if(this.user_group !== "管理员" && this.form["enterprise_no"] === 0) {
                //     this.form["enterprise_no"] = this.user.user_id;
                // }
                var json = await this.$get("~/api/user/get_list?user_group=招聘企业");
                if(json.result && json.result.list){
                    this.list_user_enterprise_no = json.result.list;
                }
                else if(json.error){
                    console.error(json.error);
                }
			},
					/**
			 * 获取招聘企业用户组
			 */
			async get_group_user_enterprise_no() {
							this.form["enterprise_no"] = this.user.user_id;
							var json = await this.$get("~/api/user_group/get_obj?name=招聘企业");
				if(json.result && json.result.obj){
					this.group_user_enterprise_no = json.result.obj;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
			get_user_session_enterprise_no(id){
				var _this = this;
				var user_id = {"user_id":id}
				var url = "~/api/"+_this.group_user_enterprise_no.source_table+"/get_obj?"
				this.$get(url, user_id, function(res) {
					if (res.result && res.result.obj) {
						var arr = []
						for (let key in res.result.obj) {
							arr.push(key)
						}
						var arrForm = []
									for (let key in _this.form) {
							arrForm.push(key)
						}
												_this.form["enterprise_no"] = id
									_this.disabledObj['enterprise_no' + '_isDisabled'] = true
						for (var i=0;i<arr.length;i++){
						  if (arr[i]!=='examine_state' && arr[i]!=='examine_reply') {
							for (var j = 0; j < arrForm.length; j++) {
							  if (arr[i] === arrForm[j]) {
								if (arr[i] !== "enterprise_no") {
			                      _this.form[arrForm[j]] = res.result.obj[arr[i]]
			                      _this.disabledObj[arrForm[j] + '_isDisabled'] = true
								  break;
								} else {
								  _this.disabledObj[arrForm[j] + '_isDisabled'] = true
								}
							  }
							}
						  }
						}
					}
				});
			},
					get_user_enterprise_no(id){
				var obj = this.list_user_enterprise_no.getObj({"user_id":id});
				var ret = "";
				if(obj){
					if(obj.nickname){
						ret = obj.nickname;}
					else{
						ret = obj.username;
					}
				}
				return ret;
			},
			
	
			
	
			
				/**
			 * 获取职位类别列表
			 */
			async get_list_position_category() {
				var json = await this.$get("~/api/position_classification/get_list?");
				if(json.result && json.result.list){
					this.list_position_category = json.result.list;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
	
			
				/**
			 * 获取地区列表
			 */
			async get_list_region() {
				var json = await this.$get("~/api/regional_management/get_list?");
				if(json.result && json.result.list){
					this.list_region = json.result.list;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
	
			
	
			
	
			
	
			
	
			
	
						/**
			 * 上传宣传图
			 * @param {Object} param 图片参数
			 */
			upload_publicity_map(param){
						this.uploadFile(param.file, "publicity_map");
					},
	
	
			
	
		
			/**
			 * 获取对象之前
			 * @param {Object} param
			 */
			get_obj_before(param) {
				var form = "";
														
				if(this.form && form){
					Object.keys(this.form).forEach(key => {
						Object.keys(form).forEach(dbKey => {
							// if(dbKey === "charging_standard"){
							// 	this.form['charging_rules'] = form[dbKey];
							// 	this.disabledObj['charging_rules_isDisabled'] = true;
							// };
							if(key === dbKey){
								this.disabledObj[key+'_isDisabled'] = true;
							}
						})
					})
				}
																												$.db.del("form");
				return param;
			},

			/**
			 * 获取对象之后
			 * @param {Object} json
			 * @param {Object} func
			 */
			get_obj_after(json, func){


																																				


			},

			/**
			 * 提交前验证事件
			 * @param {Object} 请求参数
			 * @return {String} 验证成功返回null, 失败返回错误提示
			 */
			submit_check(param) {
				let msg = null
																																										return msg;
			},

			is_view(){
				var bl = this.user_group == "管理员";

				if(!bl){
					bl = this.$check_action('/recruitment_position/table','add');
					console.log(bl ? "你有表格添加权限视作有添加权限" : "你没有表格添加权限");
				}
				if(!bl){
					bl = this.$check_action('/recruitment_position/table','set');
					console.log(bl ? "你有表格添加权限视作有修改权限" : "你没有表格修改权限");
				}
				if(!bl){
					bl = this.$check_action('/recruitment_position/view','add');
					console.log(bl ? "你有视图添加权限视作有添加权限" : "你没有视图添加权限");
				}
				if(!bl){
					bl = this.$check_action('/recruitment_position/view','set');
					console.log(bl ? "你有视图修改权限视作有修改权限" : "你没有视图修改权限");
				}
				if(!bl){
					bl = this.$check_action('/recruitment_position/view','get');
					console.log(bl ? "你有视图查询权限视作有查询权限" : "你没有视图查询权限");
				}

				console.log(bl ? "具有当前页面的查看权，请注意这不代表你有字段的查看权" : "无权查看当前页，请注意即便有字段查询权限没有页面查询权限也不行");

				return bl;
			},
			/**
			 * 上传文件
			 * @param {Object} param
			 */
			uploadimg(param) {
				this.uploadFile(param.file, "avatar");
			},

		},
		created() {
					this.get_list_user_enterprise_no();
					this.get_group_user_enterprise_no();
											this.get_list_position_category();
						this.get_list_region();
																		},
	}
</script>

<style>
	.avatar-uploader .el-upload {
		border: 1px dashed #d9d9d9;
		border-radius: 6px;
		cursor: pointer;
		position: relative;
		overflow: hidden;
	}

	.avatar-uploader .el-upload:hover {
		border-color: #409EFF;
	}

	.avatar-uploader-icon {
		font-size: 28px;
		color: #8c939d;
		width: 178px;
		height: 178px;
		line-height: 178px;
		text-align: center;
	}

	.avatar {
		width: 178px;
		height: 178px;
		display: block;
	}




</style>
