<template>
	<el-main class="bg edit_wrap">
		<el-form ref="form" :model="form" status-icon label-width="120px" v-if="is_view()">

							<el-col v-if="user_group === '管理员' || $check_field('get','enterprise_no') || $check_field('add','enterprise_no') || $check_field('set','enterprise_no')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="企业编号" prop="enterprise_no">
													<el-select v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','enterprise_no')) || (!form['resume_delivery_id'] && $check_field('add','enterprise_no'))" id="enterprise_no" v-model="form['enterprise_no']" :disabled="disabledObj['enterprise_no_isDisabled']">
							<el-option v-for="o in list_user_enterprise_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
						<el-select v-else-if="$check_field('get','enterprise_no')" id="enterprise_no" v-model="form['enterprise_no']" :disabled="true">
							<el-option v-for="o in list_user_enterprise_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','enterprise_name') || $check_field('add','enterprise_name') || $check_field('set','enterprise_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="企业名称" prop="enterprise_name">
												<el-input id="enterprise_name" v-model="form['enterprise_name']" placeholder="请输入企业名称"
							  v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','enterprise_name')) || (!form['resume_delivery_id'] && $check_field('add','enterprise_name'))" :disabled="disabledObj['enterprise_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','enterprise_name')">{{form['enterprise_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','position_name') || $check_field('add','position_name') || $check_field('set','position_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="职位名称" prop="position_name">
												<el-input id="position_name" v-model="form['position_name']" placeholder="请输入职位名称"
							  v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','position_name')) || (!form['resume_delivery_id'] && $check_field('add','position_name'))" :disabled="disabledObj['position_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','position_name')">{{form['position_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','position_category') || $check_field('add','position_category') || $check_field('set','position_category')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="职位类别" prop="position_category">
												<el-input id="position_category" v-model="form['position_category']" placeholder="请输入职位类别"
							  v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','position_category')) || (!form['resume_delivery_id'] && $check_field('add','position_category'))" :disabled="disabledObj['position_category_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','position_category')">{{form['position_category']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','user_no') || $check_field('add','user_no') || $check_field('set','user_no')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="用户编号" prop="user_no">
																		<div v-if="user_group !== '管理员'">
							{{ get_user_session_user_no(form['user_no']) }}
							<!--<el-input id="business_name" v-model="form['user_no']" placeholder="请输入用户编号"-->
							<!--v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','user_no')) || (!form['resume_delivery_id'] && $check_field('add','user_no'))" :disabled="disabledObj['user_no_isDisabled']"></el-input>-->
							<!--<div v-else-if="$check_field('get','user_no')">{{form['user_no']}}</div>-->
							<el-select v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','user_no')) || (!form['resume_delivery_id'] && $check_field('add','user_no'))" id="user_no" v-model="form['user_no']" :disabled="disabledObj['user_no_isDisabled']">
								<el-option v-for="o in list_user_user_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
										   :value="o['user_id']">
								</el-option>
							</el-select>
							<el-select v-else-if="$check_field('get','user_no')" id="user_no" v-model="form['user_no']" :disabled="true">
								<el-option v-for="o in list_user_user_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
										   :value="o['user_id']">
								</el-option>
							</el-select>
						</div>
						<el-select v-else id="user_no" v-model="form['user_no']" :disabled="disabledObj['user_no_isDisabled']">
							<el-option v-for="o in list_user_user_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
																</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','full_name') || $check_field('add','full_name') || $check_field('set','full_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="姓名" prop="full_name">
												<el-input id="full_name" v-model="form['full_name']" placeholder="请输入姓名"
							  v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','full_name')) || (!form['resume_delivery_id'] && $check_field('add','full_name'))" :disabled="disabledObj['full_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','full_name')">{{form['full_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','gender') || $check_field('add','gender') || $check_field('set','gender')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="性别" prop="gender">
												<el-input id="gender" v-model="form['gender']" placeholder="请输入性别"
							  v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','gender')) || (!form['resume_delivery_id'] && $check_field('add','gender'))" :disabled="disabledObj['gender_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','gender')">{{form['gender']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','education') || $check_field('add','education') || $check_field('set','education')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="学历" prop="education">
												<el-input id="education" v-model="form['education']" placeholder="请输入学历"
							  v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','education')) || (!form['resume_delivery_id'] && $check_field('add','education'))" :disabled="disabledObj['education_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','education')">{{form['education']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','university_one_is_graduated_from') || $check_field('add','university_one_is_graduated_from') || $check_field('set','university_one_is_graduated_from')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="毕业院校" prop="university_one_is_graduated_from">
												<el-input id="university_one_is_graduated_from" v-model="form['university_one_is_graduated_from']" placeholder="请输入毕业院校"
							  v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','university_one_is_graduated_from')) || (!form['resume_delivery_id'] && $check_field('add','university_one_is_graduated_from'))" :disabled="disabledObj['university_one_is_graduated_from_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','university_one_is_graduated_from')">{{form['university_one_is_graduated_from']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','resume') || $check_field('add','resume') || $check_field('set','resume')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="简历" prop="resume">
												<div v-if="disabledObj['resume_isDisabled']">
						<div v-if="$check_field('get','resume')">
							<el-button type="primary" @click="$download($fullUrl(form['resume']),form['resume'])">下载<i
									class="el-icon-download el-icon--right"></i></el-button>
						</div>
					</div>
					<div v-else>
						<el-upload v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','resume')) || (!form['resume_delivery_id'] && $check_field('add','resume'))" class="upload-demo" drag
								   action="" style="max-width: 300px;width: 100%;" :http-request="upload_resume" :limit="1" accept="">
							<i class="el-icon-upload"></i>
							<div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
						</el-upload>
						<div v-else-if="$check_field('get','resume')">
							<el-button type="primary" @click="$download($fullUrl(form['resume']),form['resume'])">下载<i
									class="el-icon-download el-icon--right"></i></el-button>
						</div>
					</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','self_introduction') || $check_field('add','self_introduction') || $check_field('set','self_introduction')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="自我介绍" prop="self_introduction">
								<el-input type="textarea" id="self_introduction" v-model="form['self_introduction']" placeholder="请输入自我介绍"
						v-if="user_group === '管理员' || (form['resume_delivery_id'] && $check_field('set','self_introduction')) || (!form['resume_delivery_id'] && $check_field('add','self_introduction'))" :disabled="disabledObj['self_introduction_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','self_introduction')">{{form['self_introduction']}}</div>
							</el-form-item>
			</el-col>
					
	
	
	
	
	
	
			<el-col :xs="24" :sm="12" :lg="8" class="el_form_btn_warp">
				<el-form-item>
					<el-button type="primary" @click="submit()">提交</el-button>
					<el-button @click="cancel()">取消</el-button>
				</el-form-item>
			</el-col>

		</el-form>
	</el-main>
</template>

<script>
	import mixin from "@/mixins/page.js";

	export default {
		mixins: [mixin],
		data() {
			return {
				field: "resume_delivery_id",
				url_add: "~/api/resume_delivery/add?",
				url_set: "~/api/resume_delivery/set?",
				url_get_obj: "~/api/resume_delivery/get_obj?",
				url_upload: "~/api/resume_delivery/upload?",

				query: {
					"resume_delivery_id": 0,
				},

				form: {
								"enterprise_no": 0, // 企业编号
										"enterprise_name":  '', // 企业名称
										"position_name":  '', // 职位名称
										"position_category":  '', // 职位类别
										"user_no": 0, // 用户编号
										"full_name":  '', // 姓名
										"gender":  '', // 性别
										"education":  '', // 学历
										"university_one_is_graduated_from":  '', // 毕业院校
										"resume":  '', // 简历
										"self_introduction":  '', // 自我介绍
											"resume_delivery_id": 0, // ID
						
				},
				disabledObj:{
								"enterprise_no_isDisabled": false,
										"enterprise_name_isDisabled": false,
										"position_name_isDisabled": false,
										"position_category_isDisabled": false,
										"user_no_isDisabled": false,
										"full_name_isDisabled": false,
										"gender_isDisabled": false,
										"education_isDisabled": false,
										"university_one_is_graduated_from_isDisabled": false,
										"resume_isDisabled": false,
										"self_introduction_isDisabled": false,
										},

	
					// 用户列表
				list_user_enterprise_no: [],
				
		
		
		
					// 用户列表
				list_user_user_no: [],
						// 用户组
				group_user_user_no: "",
				
		
		
		
		
		
	
			}
		},
		methods: {


	
	
				/**
			 * 获取招聘企业用户列表
			 */
			async get_list_user_enterprise_no() {
                // if(this.user_group !== "管理员" && this.form["enterprise_no"] === 0) {
                //     this.form["enterprise_no"] = this.user.user_id;
                // }
                var json = await this.$get("~/api/user/get_list?user_group=招聘企业");
                if(json.result && json.result.list){
                    this.list_user_enterprise_no = json.result.list;
                }
                else if(json.error){
                    console.error(json.error);
                }
			},
					get_user_enterprise_no(id){
				var obj = this.list_user_enterprise_no.getObj({"user_id":id});
				var ret = "";
				if(obj){
					if(obj.nickname){
						ret = obj.nickname;}
					else{
						ret = obj.username;
					}
				}
				return ret;
			},
			
	
			
	
			
	
			
	
				/**
			 * 获取注册用户用户列表
			 */
			async get_list_user_user_no() {
                // if(this.user_group !== "管理员" && this.form["user_no"] === 0) {
                //     this.form["user_no"] = this.user.user_id;
                // }
                var json = await this.$get("~/api/user/get_list?user_group=注册用户");
                if(json.result && json.result.list){
                    this.list_user_user_no = json.result.list;
                }
                else if(json.error){
                    console.error(json.error);
                }
			},
					/**
			 * 获取注册用户用户组
			 */
			async get_group_user_user_no() {
							this.form["user_no"] = this.user.user_id;
							var json = await this.$get("~/api/user_group/get_obj?name=注册用户");
				if(json.result && json.result.obj){
					this.group_user_user_no = json.result.obj;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
			get_user_session_user_no(id){
				var _this = this;
				var user_id = {"user_id":id}
				var url = "~/api/"+_this.group_user_user_no.source_table+"/get_obj?"
				this.$get(url, user_id, function(res) {
					if (res.result && res.result.obj) {
						var arr = []
						for (let key in res.result.obj) {
							arr.push(key)
						}
						var arrForm = []
									for (let key in _this.form) {
							arrForm.push(key)
						}
												_this.form["user_no"] = id
									_this.disabledObj['user_no' + '_isDisabled'] = true
						for (var i=0;i<arr.length;i++){
						  if (arr[i]!=='examine_state' && arr[i]!=='examine_reply') {
							for (var j = 0; j < arrForm.length; j++) {
							  if (arr[i] === arrForm[j]) {
								if (arr[i] !== "user_no") {
			                      _this.form[arrForm[j]] = res.result.obj[arr[i]]
			                      _this.disabledObj[arrForm[j] + '_isDisabled'] = true
								  break;
								} else {
								  _this.disabledObj[arrForm[j] + '_isDisabled'] = true
								}
							  }
							}
						  }
						}
					}
				});
			},
					get_user_user_no(id){
				var obj = this.list_user_user_no.getObj({"user_id":id});
				var ret = "";
				if(obj){
					if(obj.nickname){
						ret = obj.nickname;}
					else{
						ret = obj.username;
					}
				}
				return ret;
			},
			
	
			
	
			
	
			
	
						/**
			 * 上传简历
			 * @param {Object} param 文件参数
			 */
			upload_resume(param){
						this.uploadFile(param.file, "resume");
					},
	
	
			
	
		
			/**
			 * 获取对象之前
			 * @param {Object} param
			 */
			get_obj_before(param) {
				var form = "";
											// 获取缓存数据附加
				form = $.db.get("form");
							$.push(this.form ,form);
												
				if(this.form && form){
					Object.keys(this.form).forEach(key => {
						Object.keys(form).forEach(dbKey => {
							// if(dbKey === "charging_standard"){
							// 	this.form['charging_rules'] = form[dbKey];
							// 	this.disabledObj['charging_rules_isDisabled'] = true;
							// };
							if(key === dbKey){
								this.disabledObj[key+'_isDisabled'] = true;
							}
						})
					})
				}
																										$.db.del("form");
				return param;
			},

			/**
			 * 获取对象之后
			 * @param {Object} json
			 * @param {Object} func
			 */
			get_obj_after(json, func){


																																	


			},

			/**
			 * 提交前验证事件
			 * @param {Object} 请求参数
			 * @return {String} 验证成功返回null, 失败返回错误提示
			 */
			submit_check(param) {
				let msg = null
																																							return msg;
			},

			is_view(){
				var bl = this.user_group == "管理员";

				if(!bl){
					bl = this.$check_action('/resume_delivery/table','add');
					console.log(bl ? "你有表格添加权限视作有添加权限" : "你没有表格添加权限");
				}
				if(!bl){
					bl = this.$check_action('/resume_delivery/table','set');
					console.log(bl ? "你有表格添加权限视作有修改权限" : "你没有表格修改权限");
				}
				if(!bl){
					bl = this.$check_action('/resume_delivery/view','add');
					console.log(bl ? "你有视图添加权限视作有添加权限" : "你没有视图添加权限");
				}
				if(!bl){
					bl = this.$check_action('/resume_delivery/view','set');
					console.log(bl ? "你有视图修改权限视作有修改权限" : "你没有视图修改权限");
				}
				if(!bl){
					bl = this.$check_action('/resume_delivery/view','get');
					console.log(bl ? "你有视图查询权限视作有查询权限" : "你没有视图查询权限");
				}

				console.log(bl ? "具有当前页面的查看权，请注意这不代表你有字段的查看权" : "无权查看当前页，请注意即便有字段查询权限没有页面查询权限也不行");

				return bl;
			},
			/**
			 * 上传文件
			 * @param {Object} param
			 */
			uploadimg(param) {
				this.uploadFile(param.file, "avatar");
			},

		},
		created() {
					this.get_list_user_enterprise_no();
														this.get_list_user_user_no();
					this.get_group_user_user_no();
																	},
	}
</script>

<style>
	.avatar-uploader .el-upload {
		border: 1px dashed #d9d9d9;
		border-radius: 6px;
		cursor: pointer;
		position: relative;
		overflow: hidden;
	}

	.avatar-uploader .el-upload:hover {
		border-color: #409EFF;
	}

	.avatar-uploader-icon {
		font-size: 28px;
		color: #8c939d;
		width: 178px;
		height: 178px;
		line-height: 178px;
		text-align: center;
	}

	.avatar {
		width: 178px;
		height: 178px;
		display: block;
	}




</style>
