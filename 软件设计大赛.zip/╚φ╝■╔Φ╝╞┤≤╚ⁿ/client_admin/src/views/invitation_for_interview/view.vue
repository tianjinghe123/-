<template>
	<el-main class="bg edit_wrap">
		<el-form ref="form" :model="form" status-icon label-width="120px" v-if="is_view()">

							<el-col v-if="user_group === '管理员' || $check_field('get','enterprise_no') || $check_field('add','enterprise_no') || $check_field('set','enterprise_no')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="企业编号" prop="enterprise_no">
													<el-select v-if="user_group === '管理员' || (form['invitation_for_interview_id'] && $check_field('set','enterprise_no')) || (!form['invitation_for_interview_id'] && $check_field('add','enterprise_no'))" id="enterprise_no" v-model="form['enterprise_no']" :disabled="disabledObj['enterprise_no_isDisabled']">
							<el-option v-for="o in list_user_enterprise_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
						<el-select v-else-if="$check_field('get','enterprise_no')" id="enterprise_no" v-model="form['enterprise_no']" :disabled="true">
							<el-option v-for="o in list_user_enterprise_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','enterprise_name') || $check_field('add','enterprise_name') || $check_field('set','enterprise_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="企业名称" prop="enterprise_name">
												<el-input id="enterprise_name" v-model="form['enterprise_name']" placeholder="请输入企业名称"
							  v-if="user_group === '管理员' || (form['invitation_for_interview_id'] && $check_field('set','enterprise_name')) || (!form['invitation_for_interview_id'] && $check_field('add','enterprise_name'))" :disabled="disabledObj['enterprise_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','enterprise_name')">{{form['enterprise_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','user_no') || $check_field('add','user_no') || $check_field('set','user_no')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="用户编号" prop="user_no">
													<el-select v-if="user_group === '管理员' || (form['invitation_for_interview_id'] && $check_field('set','user_no')) || (!form['invitation_for_interview_id'] && $check_field('add','user_no'))" id="user_no" v-model="form['user_no']" :disabled="disabledObj['user_no_isDisabled']">
							<el-option v-for="o in list_user_user_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
						<el-select v-else-if="$check_field('get','user_no')" id="user_no" v-model="form['user_no']" :disabled="true">
							<el-option v-for="o in list_user_user_no" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','full_name') || $check_field('add','full_name') || $check_field('set','full_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="姓名" prop="full_name">
												<el-input id="full_name" v-model="form['full_name']" placeholder="请输入姓名"
							  v-if="user_group === '管理员' || (form['invitation_for_interview_id'] && $check_field('set','full_name')) || (!form['invitation_for_interview_id'] && $check_field('add','full_name'))" :disabled="disabledObj['full_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','full_name')">{{form['full_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','position_name') || $check_field('add','position_name') || $check_field('set','position_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="职位名称" prop="position_name">
												<el-input id="position_name" v-model="form['position_name']" placeholder="请输入职位名称"
							  v-if="user_group === '管理员' || (form['invitation_for_interview_id'] && $check_field('set','position_name')) || (!form['invitation_for_interview_id'] && $check_field('add','position_name'))" :disabled="disabledObj['position_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','position_name')">{{form['position_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','interview_time') || $check_field('add','interview_time') || $check_field('set','interview_time')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="面试时间" prop="interview_time">
								<el-date-picker :disabled="disabledObj['interview_time_isDisabled']" v-if="user_group === '管理员' || (form['invitation_for_interview_id'] && $check_field('set','interview_time')) || (!form['invitation_for_interview_id'] && $check_field('add','interview_time'))" id="interview_time"
						v-model="form['interview_time']" type="datetime" placeholder="选择日期时间">
					</el-date-picker>
					<div v-else-if="$check_field('get','interview_time')">{{form['interview_time']}}</div>
							</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','place_of_interview') || $check_field('add','place_of_interview') || $check_field('set','place_of_interview')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="面试地点" prop="place_of_interview">
												<el-input id="place_of_interview" v-model="form['place_of_interview']" placeholder="请输入面试地点"
							  v-if="user_group === '管理员' || (form['invitation_for_interview_id'] && $check_field('set','place_of_interview')) || (!form['invitation_for_interview_id'] && $check_field('add','place_of_interview'))" :disabled="disabledObj['place_of_interview_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','place_of_interview')">{{form['place_of_interview']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="user_group === '管理员' || $check_field('get','carrying_information') || $check_field('add','carrying_information') || $check_field('set','carrying_information')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="携带资料" prop="carrying_information">
								<el-input type="textarea" id="carrying_information" v-model="form['carrying_information']" placeholder="请输入携带资料"
						v-if="user_group === '管理员' || (form['invitation_for_interview_id'] && $check_field('set','carrying_information')) || (!form['invitation_for_interview_id'] && $check_field('add','carrying_information'))" :disabled="disabledObj['carrying_information_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','carrying_information')">{{form['carrying_information']}}</div>
							</el-form-item>
			</el-col>
							<el-col :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="审核状态" prop="examine_state">
					<el-select id="examine_state" v-model="form['examine_state']"
						v-if="user_group === '管理员' || (form['examine_state'] && $check_examine()) || (!form['examine_state'] && $check_examine())">
						<el-option key="未审核" label="未审核" value="未审核"></el-option>
						<el-option key="已通过" label="已通过" value="已通过"></el-option>
						<el-option key="未通过" label="未通过" value="未通过"></el-option>
					</el-select>
					<div v-else>{{form["examine_state"]}}</div>
				</el-form-item>
			</el-col>
					<el-col :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="审核回复" prop="examine_reply">
					<el-input id="examine_reply" v-model="form['examine_reply']" placeholder="请输入审核回复"
						v-if="user_group === '管理员' || (form['examine_reply'] && $check_examine()) || (!form['examine_reply'] && $check_examine())"></el-input>
					<div v-else>{{form["examine_reply"]}}</div>
				</el-form-item>
			</el-col>
	
	
	
	
	
	
	
			<el-col :xs="24" :sm="12" :lg="8" class="el_form_btn_warp">
				<el-form-item>
					<el-button type="primary" @click="submit()">提交</el-button>
					<el-button @click="cancel()">取消</el-button>
				</el-form-item>
			</el-col>

		</el-form>
	</el-main>
</template>

<script>
	import mixin from "@/mixins/page.js";

	export default {
		mixins: [mixin],
		data() {
			return {
				field: "invitation_for_interview_id",
				url_add: "~/api/invitation_for_interview/add?",
				url_set: "~/api/invitation_for_interview/set?",
				url_get_obj: "~/api/invitation_for_interview/get_obj?",
				url_upload: "~/api/invitation_for_interview/upload?",

				query: {
					"invitation_for_interview_id": 0,
				},

				form: {
								"enterprise_no": 0, // 企业编号
										"enterprise_name":  '', // 企业名称
										"user_no": 0, // 用户编号
										"full_name":  '', // 姓名
										"position_name":  '', // 职位名称
										"interview_time":  '', // 面试时间
										"place_of_interview":  '', // 面试地点
										"carrying_information":  '', // 携带资料
									"examine_state": "未审核",
							"examine_reply": "",
							"invitation_for_interview_id": 0, // ID
						
				},
				disabledObj:{
								"enterprise_no_isDisabled": false,
										"enterprise_name_isDisabled": false,
										"user_no_isDisabled": false,
										"full_name_isDisabled": false,
										"position_name_isDisabled": false,
										"interview_time_isDisabled": false,
										"place_of_interview_isDisabled": false,
										"carrying_information_isDisabled": false,
										},

	
					// 用户列表
				list_user_enterprise_no: [],
				
		
					// 用户列表
				list_user_user_no: [],
				
		
		
		
		
	
			}
		},
		methods: {


	
	
				/**
			 * 获取招聘企业用户列表
			 */
			async get_list_user_enterprise_no() {
                // if(this.user_group !== "管理员" && this.form["enterprise_no"] === 0) {
                //     this.form["enterprise_no"] = this.user.user_id;
                // }
                var json = await this.$get("~/api/user/get_list?user_group=招聘企业");
                if(json.result && json.result.list){
                    this.list_user_enterprise_no = json.result.list;
                }
                else if(json.error){
                    console.error(json.error);
                }
			},
					get_user_enterprise_no(id){
				var obj = this.list_user_enterprise_no.getObj({"user_id":id});
				var ret = "";
				if(obj){
					if(obj.nickname){
						ret = obj.nickname;}
					else{
						ret = obj.username;
					}
				}
				return ret;
			},
			
	
			
	
				/**
			 * 获取注册用户用户列表
			 */
			async get_list_user_user_no() {
                // if(this.user_group !== "管理员" && this.form["user_no"] === 0) {
                //     this.form["user_no"] = this.user.user_id;
                // }
                var json = await this.$get("~/api/user/get_list?user_group=注册用户");
                if(json.result && json.result.list){
                    this.list_user_user_no = json.result.list;
                }
                else if(json.error){
                    console.error(json.error);
                }
			},
					get_user_user_no(id){
				var obj = this.list_user_user_no.getObj({"user_id":id});
				var ret = "";
				if(obj){
					if(obj.nickname){
						ret = obj.nickname;}
					else{
						ret = obj.username;
					}
				}
				return ret;
			},
			
	
			
	
			
	
			
	
			
	
		
			/**
			 * 获取对象之前
			 * @param {Object} param
			 */
			get_obj_before(param) {
				var form = "";
															// 获取缓存数据附加
				form = $.db.get("form");
							$.push(this.form ,form);
								
				if(this.form && form){
					Object.keys(this.form).forEach(key => {
						Object.keys(form).forEach(dbKey => {
							// if(dbKey === "charging_standard"){
							// 	this.form['charging_rules'] = form[dbKey];
							// 	this.disabledObj['charging_rules_isDisabled'] = true;
							// };
							if(key === dbKey){
								this.disabledObj[key+'_isDisabled'] = true;
							}
						})
					})
				}
											        if (this.form["interview_time"].indexOf("-")===-1){
            this.form["interview_time"] = this.$toTime(parseInt(this.form["interview_time"]),"yyyy-MM-dd hh:mm:ss")
        }
										$.db.del("form");
				return param;
			},

			/**
			 * 获取对象之后
			 * @param {Object} json
			 * @param {Object} func
			 */
			get_obj_after(json, func){


																        if(this.form["interview_time"]=="0000-00-00 00:00:00"){
          this.form["interview_time"] = null;
        }
				if(parseInt(this.form["interview_time"]) > 9999){
					this.form["interview_time"] = this.$toTime(parseInt(this.form["interview_time"]),"yyyy-MM-dd hh:mm:ss")
				}
									


			},

			/**
			 * 提交前验证事件
			 * @param {Object} 请求参数
			 * @return {String} 验证成功返回null, 失败返回错误提示
			 */
			submit_check(param) {
				let msg = null
																														return msg;
			},

			is_view(){
				var bl = this.user_group == "管理员";

				if(!bl){
					bl = this.$check_action('/invitation_for_interview/table','add');
					console.log(bl ? "你有表格添加权限视作有添加权限" : "你没有表格添加权限");
				}
				if(!bl){
					bl = this.$check_action('/invitation_for_interview/table','set');
					console.log(bl ? "你有表格添加权限视作有修改权限" : "你没有表格修改权限");
				}
				if(!bl){
					bl = this.$check_action('/invitation_for_interview/view','add');
					console.log(bl ? "你有视图添加权限视作有添加权限" : "你没有视图添加权限");
				}
				if(!bl){
					bl = this.$check_action('/invitation_for_interview/view','set');
					console.log(bl ? "你有视图修改权限视作有修改权限" : "你没有视图修改权限");
				}
				if(!bl){
					bl = this.$check_action('/invitation_for_interview/view','get');
					console.log(bl ? "你有视图查询权限视作有查询权限" : "你没有视图查询权限");
				}

				console.log(bl ? "具有当前页面的查看权，请注意这不代表你有字段的查看权" : "无权查看当前页，请注意即便有字段查询权限没有页面查询权限也不行");

				return bl;
			},
			/**
			 * 上传文件
			 * @param {Object} param
			 */
			uploadimg(param) {
				this.uploadFile(param.file, "avatar");
			},

		},
		created() {
					this.get_list_user_enterprise_no();
										this.get_list_user_user_no();
															},
	}
</script>

<style>
	.avatar-uploader .el-upload {
		border: 1px dashed #d9d9d9;
		border-radius: 6px;
		cursor: pointer;
		position: relative;
		overflow: hidden;
	}

	.avatar-uploader .el-upload:hover {
		border-color: #409EFF;
	}

	.avatar-uploader-icon {
		font-size: 28px;
		color: #8c939d;
		width: 178px;
		height: 178px;
		line-height: 178px;
		text-align: center;
	}

	.avatar {
		width: 178px;
		height: 178px;
		display: block;
	}




</style>
