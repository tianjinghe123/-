<template>
  <div>
    <input type="text" id="inCode" name="inCode" /><br />
    <canvas id="cvs" onclick="changeCode()"></canvas>
  </div>
</template>

<script>
import "@/assets/js/ArithmeticVerification.js";
export default {
  name: "arithmeticVerification",
  mounted() {
  },
  methods: {

  },
};
</script>